<nav>
    <div class="container">
        <div>
            <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 hidden-xs nav-icon">
                <div class="mega-container visible-lg visible-md visible-sm">
                    <div class="navleft-container">
                        <div class="mega-menu-title">
                            <h3><i class="fa fa-navicon"></i> All Categories</h3>
                        </div>
                        <div class="mega-menu-category">
                            <ul class="nav">
                                <?php
                                    include_once 'controller/CateController.php';
                                    $CateController = new CateController(); // gọi Class CateModel bên model/CateModel.php
                                    $CateRoot = $CateController->getCate(); // hàm Cate mẹ

                                    foreach($CateRoot as $Cate_root)
                                    {
                                        $limit = 2; // Giới hạn số Cate lấy ra
                                        $total = mysqli_num_rows($CateController->Cate_Child($Cate_root['id']));
                                ?>

                                <li><a href='#'><i class='fa fa-gift'></i><?php echo $Cate_root['cate_name'];?></a>
                                    <div class="wrap-popup">
                                        <div class="popup">
                                            <div class="row">

                                                <?php for($current_start = 1; $current_start <= ceil($total/2); $current_start++){
                                                            $start = ($current_start - 1) * $limit
                                                ?>

                                                <div class="col-md-4 col-sm-6">
<!--                                                    category cấp 1-->
                                                    <?php foreach($CateController->CateChild($Cate_root['id'],$start,$limit) as $Cate_one){ ?>

                                                    <h3><?php echo $Cate_one['cate_name']; ?></h3>

                                                    <ul class="nav">
<!--                                                        category cấp 2-->
                                                        <?php foreach($CateController->Cate_Child($Cate_one['id']) as $Cate_two){ ?>

                                                        <li> <a href="?page=grid&cate=<?php echo $Cate_two['id']; ?>"><?php echo $Cate_two['cate_name']; ?></a></li>

                                                        <?php } ?>

                                                    </ul>

                                                    <?php } ?>
                                                </div>
                                                <?Php } ?>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <?php
                                    }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-md-5 col-sm-5 col-xs-3 hidden-xs category-search-form">
                <div class="search-box">
                    <form id="search_mini_form" action="?page=grid" method="get">
                        <!-- Autocomplete End code -->
                        <input name="page" value="grid" type="hidden">
                        <input id="search" type="text" name="search_product" value="" class="searchbox" maxlength="128">
                        <button type="submit" title="Search" class="search-btn-bg" id="submit-button"><span>Search</span></button>
                    </form>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 card_wishlist_area">
                <div class="mm-toggle-wrap">
                    <div class="mm-toggle"><i class="fa fa-align-justify"></i><span class="mm-label">Menu</span> </div>
                </div>
                <div class="top-cart-contain">
                    <!-- Top Cart -->
                    <div class="mini-cart">
                        <div data-toggle="dropdown" data-hover="dropdown" class="basket dropdown-toggle"> <a href="index.php?page=shopping_cart"><span class="price">My Cart</span></a> </div>
                        <?php if(isset($_SESSION['user_id'])){
                                include_once 'controller/UserController.php';
                                $UserController = new UserController();
                                $Cart = $UserController->GetToCart();
                            ?>
                        <div>
                            <div class="top-cart-content">
                                <?php foreach($Cart as $key => $CartProduct){ if($key == 0 || $key == 1){?>
                                <!--block-subtitle-->
                                <ul class="mini-products-list" id="cart-sidebar">
                                    <li class="item first">
                                        <div class="item-inner">
                                            <a class="product-image" title="Retis lapen casen" href="#l">
                                                <img alt="Retis lapen casen" src="<?php echo $CartProduct['img']; ?>">
                                            </a>
                                            <div class="product-details">
                                                <!--access--><strong><?php echo $CartProduct['qty']; ?></strong> x <span class="price">$179.99</span>
                                                <p class="product-name"><a href="#"><?php echo $CartProduct['product_name']; ?></a> </p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <?php }}?>
                                <p class="total_product">
                                <?php
                                    if ($CartProduct == null){
                                        echo 'Có 0 sản phẩm';
                                    }else{
                                    ?>
                                    Có <?php echo ($key + 1); ?> sản phẩm<?php } ?>
                                </p>
                                <!--actions-->
                                <div class="actions">
                                    <?php if ($CartProduct != null){ ?>
                                    <a href="checkout"><button class="btn-checkout" title="Checkout" type="button"><span>Checkout</span> </button></a>
                                    <?php }?>
                                    <a href="shopping-cart" class="view-cart"><span>View Cart</span></a>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    <!-- Top Cart -->
                    <div id="ajaxconfig_info" style="display:none"> <a href="#/"></a>
                        <input value="" type="hidden">
                        <input id="enable_module" value="1" type="hidden">
                        <input class="effect_to_cart" value="1" type="hidden">
                        <input class="title_shopping_cart" value="Go to shopping cart" type="hidden">
                    </div>
                </div>
            </div>
        </div>
    </div>

</nav>
