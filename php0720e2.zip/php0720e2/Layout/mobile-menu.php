<?php session_start();
    include_once 'controller/CateController.php';
    $CateController = new CateController(); // gọi Class CateModel bên model/CateModel.php
    $CateRoot = $CateController->getCate(); // hàm Cate mẹ
?>
<div id="mobile-menu">
    <ul>
        <li>
            <div class="mm-search">
                <form id="search1" name="search">
                    <div class="input-group">
                        <input name="page" value="grid" type="hidden">
                        <div class="input-group-btn">
                            <button class="btn btn-default search-btn-bg" title="Search" id="submit-button" type="submit"><i class="fa fa-search"></i> </button>
                        </div>
                        <input type="text" class="form-control simple searchbox" placeholder="Search ..." id="search" name="search_product" value="" maxlength="128">
                    </div>
                </form>
            </div>
        </li>
        <?php foreach($CateRoot as $Cate_root){?>
        <li>
            <a href="#"><?php echo $Cate_root['cate_name'];  ?></a>
            <ul>
                <?php foreach($CateController->Cate_Child($Cate_root['id']) as $Cate_one){ ?>
                <li> <a href="#" class=""><?php echo $Cate_one['cate_name']; ?></a>
                    <ul>
                        <?php foreach($CateController->Cate_Child($Cate_one['id']) as $Cate_two){ ?>
                        <li> <a href="?page=grid&cate=<?php echo $Cate_two['id']; ?>" class=""><?php echo $Cate_two['cate_name']; ?></a> </li>
                        <?php }?>
                    </ul>
                </li>
                <?php } ?>
            </ul>
        </li>
        <?php }?>
    </ul>
    <div class="top-links">
        <ul class="links">
            <?php if(isset($_SESSION['username'])){
                ?>
                <li><a title="My Account" href="dashboard">My Account</a> </li>
                <li><a title="Checkout" href="checkout">Checkout</a> </li>
                <li><a title="Logout" href='index.php?page=logout'>Log out</a></li>
            <?php }else{
                echo "<li><a title='Login' href='login'>Log In</a></li>";
            } ?>
        </ul>
    </div>
</div>
