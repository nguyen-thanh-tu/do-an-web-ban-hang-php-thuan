<header>
    <div class="header-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-2 col-sm-3 col-xs-12 logo-block">
                    <!-- Header Logo -->
                    <div class="logo"> <a title="Magento Commerce" href="/"><img alt="Magento Commerce" src="images/logo.png"> </a> </div>
                    <!-- End Header Logo -->
                </div>
                <!-- Header Language -->
                <div class="col-xs-12 col-sm-9 col-md-9 col-lg-7 pull-right hidden-xs">
                    <!-- End Header Currency -->
                    <div class="welcome-msg hidden-xs">
                        <?php if(isset($_SESSION['username'])){ echo 'welcome '.$_SESSION['username'];} ?>
                    </div>
                    <!-- Header Top Links -->
                    <div class="toplinks">
                        <div class="links">
                            <?php if(isset($_SESSION['username'])){ echo "<div class='myaccount'><a title='My Account' href='dashboard'><span class='hidden-xs'>My Account</span></a> </div>";} ?>
                            <?php if(isset($_SESSION['username'])){ echo "<div class='check'><a title='Checkout' href='checkout'><span class='hidden-xs'>Checkout</span></a> </div>";} ?>
                            <!-- Header Company -->
                            <div class="dropdown block-company-wrapper hidden-xs"> <a role="button" data-toggle="dropdown" data-target="#" class="block-company dropdown-toggle" href="#"> Company <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li role="presentation"><a href="index.php?page=about_us"> About Us </a> </li>
                                    <li role="presentation"><a href="#"> Customer Service </a> </li>
                                    <li role="presentation"><a href="#"> Privacy Policy </a> </li>
                                    <li role="presentation"><a href="index.php?page=sitemap">Site Map </a> </li>
                                    <li role="presentation"><a href="#">Search Terms </a> </li>
                                    <li role="presentation"><a href="#">Advanced Search </a> </li>
                                </ul>
                            </div>
                            <!-- End Header Company -->
                            <?php if(isset($_SESSION['username'])){
                                echo "<div class='logout'><a href='index.php?page=logout'><span class='hidden-xs'>Log out</span></a></div>";
                            }else{
                                echo "<div class='login'><a href='login'><span class='hidden-xs'>Log In</span></a></div>";
                            } ?>
                        </div>
                    </div>
                    <!-- End Header Top Links -->
                </div>
            </div>
        </div>
    </div>
</header>