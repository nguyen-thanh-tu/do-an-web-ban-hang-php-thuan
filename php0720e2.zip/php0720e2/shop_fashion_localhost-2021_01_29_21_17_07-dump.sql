-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: shop_fashion
-- ------------------------------------------------------
-- Server version	8.0.22-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin`
--

LOCK TABLES `tbl_admin` WRITE;
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
INSERT INTO `tbl_admin` VALUES (1,'admin','15E2B0D3C33891EBB0F1EF609EC419420C20E320CE94C65FBC8C3312448EB225','admin');
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_cate`
--

DROP TABLE IF EXISTS `tbl_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_cate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cate_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cate_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cate_stt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cate`
--

LOCK TABLES `tbl_cate` WRITE;
/*!40000 ALTER TABLE `tbl_cate` DISABLE KEYS */;
INSERT INTO `tbl_cate` VALUES (1,'0','Women','2020-12-18 20:33:20','1'),(2,'1','Clothing','2020-12-18 20:35:37','1'),(3,'1','Emty','2020-12-18 20:35:37','1'),(4,'1','Clothin','2020-12-18 20:35:37','1'),(5,'1','Clothin','2020-12-18 20:35:37','1'),(6,'2','Western Wear','2020-12-18 20:35:37','1'),(7,'2','Night Wear','2020-12-18 20:35:37','1'),(8,'2','Ethnic Wear','2020-12-18 20:35:37','1'),(9,'2','Designer Wear','2020-12-18 20:35:37','1'),(10,'3','Bracelets','2020-12-18 20:35:37','1'),(11,'3','Necklaces & Pendent','2020-12-18 20:35:37','1'),(12,'3','Pendants','2020-12-18 20:35:37','1'),(13,'3','Pins & Brooches','2020-12-18 20:35:37','1'),(14,'4','Flat Shoes','2020-12-18 20:35:37','1'),(15,'4','Flat Sandals','2020-12-18 20:35:37','1'),(16,'4','Boot','2020-12-18 20:35:37','1'),(17,'4','Heels','2020-12-18 20:35:37','1'),(18,'5','Swimsuits','2020-12-18 20:35:37','1'),(19,'5','Beach Clothing','2020-12-18 20:35:37','1'),(20,'5','Clothing','2020-12-18 20:35:37','1'),(21,'5','Bikinis','2020-12-18 20:35:37','1'),(22,'0','Men','2020-12-18 20:42:01','1'),(23,'22','Clothing','2020-12-18 20:42:01','1'),(24,'22','Watches','2020-12-18 20:42:01','1'),(25,'22','Sunglasses','2020-12-18 20:42:01','1'),(26,'22','Shoes','2020-12-18 20:42:01','1'),(27,'23','Casual Dress','2020-12-18 20:42:01','1'),(28,'23','Eventing','2020-12-18 20:42:01','1'),(30,'23','Party','2020-12-18 20:42:01','1'),(31,'24','Fasttrack','2020-12-18 20:42:01','1'),(32,'24','Casio','2020-12-18 20:42:01','1'),(33,'24','Titan','2020-12-18 20:42:01','1'),(34,'24','Tommy-Hilfiger','2020-12-18 20:42:01','1'),(35,'25','Rdy Ban','2020-12-18 20:42:01','1'),(36,'25','Fasttrack','2020-12-18 20:42:01','1'),(37,'25','Police','2020-12-18 20:42:01','1'),(38,'25','Oakley','2020-12-18 20:42:01','1'),(39,'26','Sport Shoes','2020-12-18 20:42:01','1'),(40,'26','Casual Shoes','2020-12-18 20:42:01','1'),(41,'26','Leather Shoes','2020-12-18 20:42:01','1'),(42,'26','Canvas Shoes','2020-12-18 20:42:01','1'),(44,'0','Lesiban','2021-01-22 14:24:14','1');
/*!40000 ALTER TABLE `tbl_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_detail_cart`
--

DROP TABLE IF EXISTS `tbl_detail_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_detail_cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `qty` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id___fk` (`user_id`),
  KEY `product_id_cart___fk` (`product_id`),
  CONSTRAINT `product_id_cart___fk` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`id`),
  CONSTRAINT `user_id___fk` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_detail_cart`
--

LOCK TABLES `tbl_detail_cart` WRITE;
/*!40000 ALTER TABLE `tbl_detail_cart` DISABLE KEYS */;
INSERT INTO `tbl_detail_cart` VALUES (9,2,12,1),(110,1,123,1),(111,1,108,1),(112,1,122,1);
/*!40000 ALTER TABLE `tbl_detail_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_detail_image`
--

DROP TABLE IF EXISTS `tbl_detail_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_detail_image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `img` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id_fk` (`product_id`),
  CONSTRAINT `product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_detail_image`
--

LOCK TABLES `tbl_detail_image` WRITE;
/*!40000 ALTER TABLE `tbl_detail_image` DISABLE KEYS */;
INSERT INTO `tbl_detail_image` VALUES (112,105,'products-images/16107153959b7670e525e79a6150556aef4531748d.png'),(113,105,'products-images/16107153959eec9de0133fbd699e12f13ae44480a8.png'),(114,105,'products-images/16107153959eec9de0133fbd699e12f13ae44480a8(1).png'),(115,105,'products-images/161071539561Hzj+QOX4L._UY500_.jpg'),(116,105,'products-images/161071539561Hzj+QOX4L._UY500_(1).jpg'),(117,108,'products-images/1610716617201262223231676964.jpg'),(118,108,'products-images/1610716617201262223231919261.jpg');
/*!40000 ALTER TABLE `tbl_detail_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_detail_order`
--

DROP TABLE IF EXISTS `tbl_detail_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_detail_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` float NOT NULL,
  `total` float NOT NULL,
  `stt` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`id`),
  CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_detail_order`
--

LOCK TABLES `tbl_detail_order` WRITE;
/*!40000 ALTER TABLE `tbl_detail_order` DISABLE KEYS */;
INSERT INTO `tbl_detail_order` VALUES (1,36,25,3,309.67,929,'1'),(2,36,24,1,309.67,310,'1'),(3,37,25,3,309.67,929,'1'),(4,37,24,1,309.67,310,'1'),(5,38,25,3,309.67,929,'1'),(6,38,24,1,309.67,310,'1'),(7,39,25,10,309.67,3097,'1'),(8,39,24,1,309.67,310,'1'),(9,40,24,1,309.67,310,'1'),(10,41,24,1,309.67,310,'1'),(11,42,24,1,309.67,310,'1'),(12,44,26,1,309.67,310,'1'),(13,45,24,1,309.67,310,'1'),(14,46,25,1,309.67,310,'1'),(15,47,25,1,309.67,310,'1'),(16,51,24,1,309.67,309.67,'1'),(17,52,24,2,309.67,619.34,'1'),(18,52,26,1,309.67,309.67,'1'),(19,53,25,1,309.67,309.67,'1'),(20,53,24,1,309.67,309.67,'1'),(21,54,24,3,309.67,929.011,'1'),(22,54,26,1,309.67,309.67,'1'),(23,55,15,2,309.67,619.34,'1'),(24,55,24,1,309.67,309.67,'1'),(25,56,26,1,309.67,309.67,'1'),(26,57,105,1,108.24,108.24,'1'),(27,58,25,7,309.67,2167.69,'1'),(28,58,24,1,309.67,309.67,'1'),(29,59,105,1,108.24,108.24,'1'),(30,60,24,1,309.67,309.67,'1'),(31,61,25,1,309.67,309.67,'1'),(32,62,25,1,309.67,309.67,'1'),(33,63,120,1,97.17,97.17,'1'),(34,63,123,1,97.17,97.17,'1'),(35,63,122,1,97.17,97.17,'1');
/*!40000 ALTER TABLE `tbl_detail_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_member`
--

DROP TABLE IF EXISTS `tbl_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `member_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_phone` int NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_member_tbl_user_id_fk` (`user_id`),
  CONSTRAINT `tbl_member_tbl_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_member`
--

LOCK TABLES `tbl_member` WRITE;
/*!40000 ALTER TABLE `tbl_member` DISABLE KEYS */;
INSERT INTO `tbl_member` VALUES (60,1,'',0,''),(61,1,'',0,''),(62,1,'',0,''),(63,1,'',0,''),(64,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(65,1,'    ',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(66,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(67,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(68,1,' ',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(69,1,' ',0,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(70,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(71,1,'',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(72,1,'',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(73,1,'',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(74,1,'',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(75,1,'     t',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(76,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(77,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(78,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(79,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(80,1,'',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(81,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(82,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(83,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(84,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(85,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(86,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở'),(87,1,'Nguyễn Thanh Tú',965787569,'34/Đường Đăc Sở 1/Thôn Đông/ Đắc Sở');
/*!40000 ALTER TABLE `tbl_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `order_note` text COLLATE utf8mb4_unicode_ci,
  `order_stt` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `member_id` FOREIGN KEY (`member_id`) REFERENCES `tbl_member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_order`
--

LOCK TABLES `tbl_order` WRITE;
/*!40000 ALTER TABLE `tbl_order` DISABLE KEYS */;
INSERT INTO `tbl_order` VALUES (36,60,'','1','2020-12-29 01:21:06'),(37,61,'','1','2020-12-29 01:29:17'),(38,62,'','1','2020-12-29 01:30:52'),(39,63,'','1','2020-12-29 20:06:21'),(40,64,'sixe s','1','2020-12-29 22:53:38'),(41,65,'','5','2020-12-29 23:02:54'),(42,66,'','1','2020-12-29 23:03:31'),(43,67,'','1','2020-12-29 23:03:38'),(44,68,'','1','2020-12-29 23:04:09'),(45,69,'','1','2020-12-29 23:05:20'),(46,70,'','2','2020-12-29 23:36:21'),(47,71,'','1','2020-12-30 21:49:35'),(48,72,'','1','2020-12-30 21:49:37'),(49,73,'','1','2020-12-30 21:49:41'),(50,74,'','4','2020-12-30 21:49:44'),(51,75,'123','5','2020-12-31 21:46:25'),(52,76,'tu','1','2021-01-06 20:20:50'),(53,77,'5656','1','2021-01-06 20:22:18'),(54,78,'onlnlkl','5','2021-01-06 20:28:49'),(55,79,'okok','3','2021-01-07 20:25:14'),(56,80,'','2','2021-01-07 22:07:57'),(57,81,'okokok','2','2021-01-13 19:18:52'),(58,82,'đặt cho a 2 cái áo','5','2021-01-15 13:14:18'),(59,83,'dasd','1','2021-01-15 13:16:10'),(60,84,'3123','4','2021-01-15 13:19:30'),(61,85,'321','3','2021-01-15 13:26:32'),(62,86,'ok','2','2021-01-16 11:25:42'),(63,87,'ook','1','2021-01-19 14:12:18');
/*!40000 ALTER TABLE `tbl_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_product`
--

DROP TABLE IF EXISTS `tbl_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cate_id` int NOT NULL,
  `product_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float NOT NULL,
  `img` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `discount` float DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_creat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stt` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_product_slug_uindex` (`slug`),
  KEY `cate_id` (`cate_id`),
  FULLTEXT KEY `name` (`product_name`),
  CONSTRAINT `cate_id` FOREIGN KEY (`cate_id`) REFERENCES `tbl_cate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_product`
--

LOCK TABLES `tbl_product` WRITE;
/*!40000 ALTER TABLE `tbl_product` DISABLE KEYS */;
INSERT INTO `tbl_product` VALUES (12,9,'Swim-wear',315.99,'products-images/product1.jpg','blue-wear',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 21:35:51','2'),(13,41,'ÔKKO',90,'products-images/product1.jpg','OKKO',100,30,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-23 22:19:09','2'),(15,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-1',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 21:35:51','3'),(16,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-2',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 21:35:51','1'),(19,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-3',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 21:35:51','3'),(22,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-4',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 21:35:51','1'),(23,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-5',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 21:35:51','4'),(24,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-6',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 21:35:51','3'),(25,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-7',100,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 20:27:08','1'),(26,7,'Blue-wear',315.99,'products-images/product1.jpg','blue-wear-8',0,2,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla. Donec a neque libero. Pellentesque aliquet, sem eget laoreet ultrices, ipsum metus feugiat sem, quis fermentum turpis eros eget velit. Donec ac tempus ante. Fusce ultricies massa massa. Fusce aliquam, purus eget sagittis vulputate, sapien libero hendrerit est, sed commodo augue nisi non neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio quis mi. Cras neque metus, consequat et blandit et, luctus a nunc. Etiam gravida vehicula tellus, in imperdiet ligula euismod eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam erat mi, rutrum at sollicitudin rhoncus, ultricies posuere erat. Duis convallis, arcu nec aliquam consequat, purus felis vehicula felis, a dapibus enim lorem nec augue.\n\nNunc facilisis sagittis ullamcorper. Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus. Sed et lorem nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean eleifend laoreet congue. Vivamus adipiscing nisl ut dolor dignissim semper. Nulla luctus malesuada tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer enim purus, posuere at ultricies eu, placerat a felis. Suspendisse aliquet urna pretium eros convallis interdum. Quisque in arcu id dui vulputate mollis eget non arcu. Aenean et nulla purus. Mauris vel tellus non nunc mattis lobortis.','2020-12-19 20:27:08','4'),(105,1,'tu',123,'products-images/1610468542shoes-4.jpg','tu',70,12,'<p>jnkn</p>\r\n','2021-01-12 22:03:15','1'),(108,22,'Nguyễn Thanh Tú',123,'products-images/1610716617201262223231676964.jpg','Nguyen-Thanh-Tu',70,1,'<p>Sản phẩm c&oacute; 1 o2</p>\r\n','2021-01-15 20:16:57','3'),(109,22,'Áo nam',123,'products-images/1611037460product11.jpg','Ao-nam-1',70,21,'<p>&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;</p>\r\n','2021-01-19 13:24:20','1'),(111,22,'Áo nam',123,'products-images/1611037510product12.jpg','Ao-nam-2',70,21,'<p>&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;&Aacute;o Nam&nbsp;</p>\r\n','2021-01-19 13:25:10','1'),(112,22,'Áo nam 2',123,'products-images/1611037595product13.jpg','Ao-nam-3',70,31,'<p>&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2</p>\r\n','2021-01-19 13:26:35','1'),(113,22,'Áo nam 2',123,'products-images/1611037608product14.jpg','Ao-nam-4',70,31,'<p>&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2</p>\r\n','2021-01-19 13:26:48','1'),(114,22,'Áo nam 2',123,'products-images/1611037631product16.jpg','Ao-nam-5',70,31,'<p>&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2</p>\r\n','2021-01-19 13:27:11','1'),(115,22,'Áo nam 2',123,'products-images/1611037643product19.jpg','Ao-nam-6',70,31,'<p>&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2&nbsp;&Aacute;o nam 2</p>\r\n','2021-01-19 13:27:23','1'),(116,1,'Váy Nữ',123,'products-images/1611038125product2.jpg','Vay-Nu',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:35:25','1'),(117,1,'Váy Nữ2',123,'products-images/1611038144product3.jpg','Vay-Nu2',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:35:44','1'),(118,1,'Váy Nữ2',123,'products-images/1611038154product4.jpg','Vay-Nu3',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:35:54','1'),(119,1,'Váy Nữ2',123,'products-images/1611038165product5.jpg','Vay-Nu4',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:36:05','1'),(120,1,'Váy Nữ2',123,'products-images/1611038173product6.jpg','Vay-Nu5',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:36:13','1'),(121,1,'Váy Nữ2',123,'products-images/1611038184product8.jpg','Vay-Nu6',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:36:24','1'),(122,1,'Váy Nữ2',123,'products-images/1611038204product9.jpg','Vay-Nu7',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:36:44','1'),(123,1,'Váy Nữ2',123,'products-images/1611038220product10.jpg','Vay-Nu8',70,21,'<p>V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ&nbsp;V&aacute;y Nữ</p>\r\n','2021-01-19 13:37:00','1');
/*!40000 ALTER TABLE `tbl_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rating`
--

DROP TABLE IF EXISTS `tbl_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_rating` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  `rating` int NOT NULL,
  `comment` longtext,
  `creat_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tbl_rating___prod_id` (`product_id`),
  KEY `tbl_rating___user_id` (`user_id`),
  CONSTRAINT `tbl_rating___prod_id` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`id`),
  CONSTRAINT `tbl_rating___user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rating`
--

LOCK TABLES `tbl_rating` WRITE;
/*!40000 ALTER TABLE `tbl_rating` DISABLE KEYS */;
INSERT INTO `tbl_rating` VALUES (25,25,1,5,'ok','2021-01-14 20:11:37'),(26,26,1,2,'ada','2021-01-14 20:13:53'),(27,26,2,3,'sdaf','2021-01-14 20:26:31');
/*!40000 ALTER TABLE `tbl_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_phone` int NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES (1,'tutotuong',965787569,'nguyenthanhtu17032000@gmail.com','a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),(2,'tutotuonge',965787562,'nguyenthanhtu170300@gmail.com','da70dfa4d9f95ac979f921e8e623358236313f334afcd06cddf8a5621cf6a1e9'),(3,'tutotuo',965787570,'nguyen@gmail.com','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),(4,'szs',1065787569,'nguyent@gmail.com','a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),(5,'fanlfsad',976287356,'nguyent7032000@gmail.com','a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),(6,'nfosjdifsd',978193819,'nguyent000@gmail.com','a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),(7,'nfiosad',965787569,'nguyeu17032000@gmail.com','a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'),(8,'tutotuongdaư',965787569,'nguyenthanhtu17032000@gmail.comeq','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),(9,'tutotuongewqeq',965787569,'nguyenthanhtu170320@gmail.com','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),(10,'tutotuongsdfsdf',965787569,'nguyenthanhtu17032000eqwe@gmail.com','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),(11,'tutotuongsdfsdfasd',965787563,'nguyenthanhtu1703@gmail.com','dbb1ded63bc70732626c5dfe6c7f50ced3d560e970f30b15335ac290358748f6'),(12,'tutotuond',965787563,'nguyenthanhtu113703@gmail.com','6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918'),(13,'tutotuongx',965782569,'nguyenthanhtu1703200dd0@gmail.com','a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3');
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-29 21:17:08
