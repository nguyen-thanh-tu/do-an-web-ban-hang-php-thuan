<?php
include_once 'config/config.php';
class ProductModel{
    public function getNewProduct($cate_id,$limit){
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE cate_id IN ($cate_id) ORDER BY id DESC LIMIT 0,$limit;";
        return mysqli_query($conn,$sql);
    }

    public function getProduct($product_id){
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE id = $product_id;";
        return mysqli_query($conn,$sql);
    }

    public function getProduct_slug($slug){
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE slug = '$slug';";
        return mysqli_query($conn,$sql);
    }

    public function getProductbyStt($stt,$start,$limit){
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE stt IN ($stt) ORDER BY id DESC LIMIT $start,$limit;";
        return mysqli_query($conn,$sql);
    }

    public function getImage($product_id){
        global $conn;
        $sql = "SELECT * FROM tbl_detail_image WHERE product_id = $product_id;";
        return mysqli_query($conn,$sql);
    }

    public function getProduct_cate($cate_id,$start,$limit){
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE cate_id IN ($cate_id) ORDER BY id DESC LIMIT $start,$limit;";
        return mysqli_query($conn,$sql);
    }

    public function CountProduct_cate($cate_id){ // tính tổng record san pham theo danh muc
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE cate_id IN ($cate_id);";
        return mysqli_num_rows(mysqli_query($conn,$sql));
    }

    public function Search_Product($search,$start,$limit){
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE product_name like '%$search%'ORDER BY id DESC LIMIT $start,$limit;";
        return mysqli_query($conn,$sql);
    }

    public function Count_Search_Product($search){ // tính tổng record san pham theo danh muc
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE product_name like '%$search%';";
        return mysqli_num_rows(mysqli_query($conn,$sql));
    }

    public function AddRating($product_id,$user_id,$rating,$comment){
        global $conn;
        $sql = "INSERT INTO tbl_rating (product_id,user_id,rating,comment) VALUES ($product_id,$user_id,$rating,'$comment')";
        return mysqli_query($conn,$sql);
    }

    public function TotalRatingProd($product_id,$user_id){
        global $conn;
        $sql = "SELECT * FROM tbl_rating WHERE user_id = $user_id AND product_id = $product_id";
        return mysqli_num_rows(mysqli_query($conn,$sql));
    }

    public function EditRating($product_id,$user_id,$rating,$comment){
        global $conn;
        $sql = "UPDATE tbl_rating SET rating = $rating, comment = '$comment' WHERE product_id = $product_id AND user_id = $user_id";
        return mysqli_query($conn,$sql);
    }

    public function GetRating($product_id){
        global $conn;
        $sql = "SELECT * FROM tbl_rating WHERE product_id = $product_id";
        return mysqli_query($conn,$sql);
    }

    public function CountStar($product_id){
        $Rating_Comment = $this->GetRating($product_id);
        $total_rating = 0;
        foreach($Rating_Comment as $value){
            $totalStar = $totalStar + $value['rating'];
            $total_rating++;
        }
        return $totalStar/$total_rating;
    }
}