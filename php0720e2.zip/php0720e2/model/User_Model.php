<?php
include_once 'config/config.php';
class User_Model{
    function getUser($user_id){
        global $conn;
        $sql = "SELECT * FROM tbl_user WHERE id ='$user_id'";
        return mysqli_fetch_array(mysqli_query($conn,$sql));
    }

    function Change_pass($user_id,$pass){
        global $conn;
        $sql = "UPDATE tbl_user SET password = '$pass' WHERE id = $user_id";
        return mysqli_query($conn,$sql);
    }

    function getAcc(){
        global $conn;
        $sql = "SELECT * FROM tbl_user";
        return mysqli_query($conn,$sql);
    }

    function Change_pass_email($email,$pass){
        global $conn;
        $sql = "UPDATE tbl_user SET password = '$pass' WHERE email = '$email'";
        return mysqli_query($conn,$sql);
    }
}
?>
