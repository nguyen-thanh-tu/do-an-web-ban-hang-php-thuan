<?php
include_once 'config/config.php';
class CateModel{
    public function CateRoot(){ // hàm Cate mẹ
        global $conn;
        $sql = "SELECT * FROM tbl_cate WHERE parent_id = 0;";
        return mysqli_query($conn,$sql);
    }

    public function CateRootId($id){ // hàm Cate mẹ
        global $conn;
        $sql = "SELECT * FROM tbl_cate WHERE id = $id;";
        return mysqli_query($conn,$sql);
    }

    public function CateChild($parent_id,$start,$limit){ // hàm Cate con giới hạn kết quả trả về
        global $conn;
        $sql = "SELECT * FROM tbl_cate WHERE parent_id = '$parent_id' LIMIT $start,$limit;";
        return mysqli_query($conn,$sql);
    }
    public function Cate_Child($parent_id){ // hàm Cate con không giới hạn kết quả trả về
        global $conn;
        $sql = "SELECT * FROM tbl_cate WHERE parent_id = '$parent_id';";
        return mysqli_query($conn,$sql);
    }

    public function GetCate($id){
        global $conn;
        $sql = "SELECT * FROM tbl_cate WHERE id = '$id';";
        return mysqli_query($conn,$sql);
    }
}
?>