<?php
include_once '../config/config.php';
class UserModel{
    public function register($user_name,$user_phone,$email,$password){
        global $conn;
        $sql = "INSERT INTO tbl_user(user_name,user_phone,email,password) value ('$user_name','$user_phone','$email','$password')";
        return mysqli_query($conn,$sql);
    }
    function total($total){
        return mysqli_num_rows($total);
    }
    function getUser($username){
        global $conn;
        $sql = "SELECT * FROM tbl_user WHERE user_name='$username'";
        return mysqli_query($conn,$sql);
    }
    function check_username($username){
        global $conn;
        $sql = "SELECT user_name FROM tbl_user WHERE user_name='$username'";
        return mysqli_num_rows(mysqli_query($conn,$sql));
    }
    function check_email($email){
        global $conn;
        $sql = "SELECT user_name FROM tbl_user WHERE email='$email'";
        return mysqli_num_rows(mysqli_query($conn,$sql));
    }
    function check_phone($phone){
        global $conn;
        $sql = "SELECT user_name FROM tbl_user WHERE user_phone='$phone'";
        return mysqli_num_rows(mysqli_query($conn,$sql));
    }
    // cart
    // lay Id san pham trong gio hang
    public function Inventory($product_id){
        global $conn;
        $sql = "SELECT quantity FROM tbl_product WHERE id = $product_id;";
        $Inventory = mysqli_fetch_array(mysqli_query($conn,$sql));
        return $Inventory['quantity'];
    }
    public function ProductCartID($user_id,$product_id){
        global $conn;
        $sql = "SELECT * FROM tbl_detail_cart WHERE user_id = $user_id AND product_id = $product_id";
        return mysqli_fetch_array(mysqli_query($conn,$sql));
    }

    // Kiem tra san pham trùng lặp trong giỏ hàng
    public function CheckToCart($user_id,$product_id){
        global $conn;
        $sql = "SELECT * FROM tbl_detail_cart WHERE user_id = $user_id AND product_id = $product_id";
        return mysqli_num_rows(mysqli_query($conn,$sql));
    }

    // Thêm sản phẩm vào giỏ hàng
    public function AddToCart($user_id,$product_id,$qty){
        global $conn;
        $sql = "INSERT INTO tbl_detail_cart(user_id,product_id,qty) VALUE ($user_id,$product_id,$qty)";
        return mysqli_query($conn,$sql);
    }

    // câp nhật giỏ hàng
    public function UpdateCart($user_id,$product_id,$qty){
        global $conn;
        $sql = "UPDATE tbl_detail_cart SET qty = $qty WHERE user_id = $user_id AND product_id = $product_id";
        return mysqli_query($conn,$sql);
    }

    // lấy thông tin giỏ hàng
    public function GetToCart($user_id){
        global $conn;
        $sql = "SELECT * FROM tbl_detail_cart,tbl_product WHERE tbl_detail_cart.user_id = $user_id AND tbl_detail_cart.product_id = tbl_product.id";
        return mysqli_query($conn,$sql);
    }

    //Xóa giỏ hàng

    public function DeleteCart($user_id,$product_id){
        global $conn;
        $sql = "DELETE FROM tbl_detail_cart WHERE user_id = $user_id AND product_id = $product_id";
        return mysqli_query($conn,$sql);
    }

    public function DelCartAll($user_id){
        global $conn;
        $sql = "DELETE FROM tbl_detail_cart WHERE user_id = $user_id";
        return mysqli_query($conn,$sql);
    }

    public function getProduct($product_id){
        global $conn;
        $sql = "SELECT * FROM tbl_product WHERE id = $product_id;";
        return mysqli_fetch_array(mysqli_query($conn,$sql));
    }
    //end cart

    //Order
    // thêm thông tin khách hàng đơn hàng
    function AddtoMember($user_id,$name,$phone,$address){
        global $conn;
        $sql = "INSERT INTO tbl_member(user_id,member_name,member_phone,address) VALUE ('$user_id','$name','$phone','$address');";
        return mysqli_query($conn,$sql);
    }

    // lấy thông tin khách hàng đơn hàng
    public function GetMember($user_id){
        global $conn;
        $sql = "SELECT * FROM tbl_member WHERE user_id = $user_id";
        return mysqli_query($conn,$sql);
    }

    // thêm đơn hàng
    public function AddOrder($member_id,$order_note,$order_stt){
        global $conn;
        $sql = "INSERT INTO tbl_order(member_id,order_note,order_stt) VALUE ('$member_id','$order_note','$order_stt');";
        return mysqli_query($conn,$sql);
    }

    // lấy đơn hàng
    public function GetOrder($member_id){
        global $conn;
        $sql = "SELECT * FROM tbl_order WHERE member_id = '$member_id'";
        return mysqli_query($conn,$sql);
    }

    // thêm sản phẩm vào đơn hàng
    public function AddProductOrder($order_id,$product_id,$quantity,$price,$total,$status){
        global $conn;
        $sql = "INSERT INTO tbl_detail_order(order_id,product_id,quantity,price,total,stt) VALUE ('$order_id','$product_id','$quantity','$price','$total','$status');";
        return mysqli_query($conn,$sql);
    }

    // hiển thị đơn hàng
    public function Show_Order($user_id){
        global $conn;
        $sql = "SELECT * FROM tbl_member,tbl_order WHERE tbl_order.member_id = tbl_member.id and tbl_member.user_id = '$user_id';";
        return mysqli_query($conn,$sql);
    }
    public function ShowOrder($user_id,$start,$limit){
        global $conn;
        $sql = "SELECT * FROM tbl_member,tbl_order WHERE tbl_order.member_id = tbl_member.id and tbl_member.user_id = '$user_id' ORDER BY tbl_order.id DESC LIMIT $start,$limit;";
        return mysqli_query($conn,$sql);
    }

    //hiển thị sản phẩm đơn hàng
    public function ProductOrder($order_id){
        global $conn;
        $sql = "SELECT * FROM tbl_detail_order WHERE order_id = '$order_id'";
        return mysqli_query($conn,$sql);
    }

    public function ShowMemberId($order_id){
        global $conn;
        $sql = "SELECT * FROM tbl_order WHERE id = '$order_id'";
        return mysqli_fetch_array(mysqli_query($conn,$sql));
    }

    public function ShowMemberOrder($member_id){
        global $conn;
        $sql = "SELECT * FROM tbl_member WHERE id = '$member_id'";
        return mysqli_fetch_array(mysqli_query($conn,$sql));
    }
    //End order
}
?>
