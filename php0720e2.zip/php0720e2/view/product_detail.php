﻿<?php
    session_start();
    $ProductModel = new ProductModel();
    $product_id = $_GET['product_id'];

    $slug = $_GET['slug'];

    $User_Controller = new User_Controller();

    $Cate = new CateModel();
    $product = mysqli_fetch_array($ProductModel->getProduct_slug($slug));

    $Rating_Comment = $ProductModel->GetRating($product_id);
    $total_rating = 0;
    foreach($Rating_Comment as $value){
        $totalStar = $totalStar + $value['rating'];
        $total_rating++;
    }
    $average_rating = $totalStar/$total_rating;
    if(isset($product)){
        $product_img = $ProductModel->getImage($product_id);
        $ProductCate = mysqli_fetch_array($Cate->GetCate($product['cate_id']));
        $CateChild_2 = mysqli_fetch_array($Cate->GetCate($ProductCate['parent_id']));
        $CateChild_1 = mysqli_fetch_array($Cate->GetCate($CateChild_2['parent_id']));
        if($product_id === '0'){
            header('location: /');
        }
    }else{
        header('location: /');
    }
?>
<div class="notice">
<?php
$Cate_1 = [$CateChild_1['id']];
$Cate1 = $Cate->Cate_Child($CateChild_1['id']);
foreach($Cate1 as $value){
    $Cate_1[] = $value['id'];
    $Cateroot = $Cate->Cate_Child($value['id']);
    foreach ($Cateroot as $value1){
        $Cate_1[] = $value1['id'];
    }
}
$string1 = implode(',', $Cate_1); // lấy chuỗi cate mẹ
$Cate_2 = [$CateChild_2['id']];
$Cate2 = $Cate->Cate_Child($CateChild_2['id']);
foreach($Cate2 as $value){
    $Cate_2[] = $value['id'];
}
$string2 = implode(',', $Cate_2);
?>
</div>
<!-- Breadcrumbs -->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <ul>
                    <li class="home"> <a href="index.php" title="Go to Home Page">Home</a> <span>/</span> </li>
                    <li class="category1599"> <a href="?page=grid&cate=<?php echo $string1; ?>" title=""><?php echo $CateChild_1['cate_name']; ?></a> <span>/ </span> </li>
                    <li class="category1600"> <a href="?page=grid&cate=<?php echo $string2; ?>" title=""><?php echo $CateChild_2['cate_name']; ?></a> <span>/</span> </li>
                    <li class="category1601"> <a href="?page=grid&cate=<?php echo $ProductCate['id']; ?>" title=""><strong><?php echo $ProductCate['cate_name']; ?></strong> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->
<!-- Main Container -->
<section class="main-container col1-layout">
    <div class="main">
        <div class="container">
            <div class="row">
                <div class="col-main">
                    <div class="product-view">
                        <div class="product-essential">
                            <form action="#" method="post" id="product_addtocart_form">
                                <input name="form_key" value="6UbXroakyQlbfQzK" type="hidden">
                                <input type="hidden" id="Product_id" value="<?php echo $product['id']; ?>" >
                                <div class="product-img-box col-lg-4 col-sm-5 col-xs-12">
                                    <div class="new-label new-top-left"> New </div>
                                    <div class="product-image">
                                        <div class="product-full"> <img id="product-zoom" src="<?php echo $product['img']; ?>" data-zoom-image="<?php echo $product['img']; ?>" alt="product-image"> </div>
                                        <div class="more-views">
                                            <div class="slider-items-products">
                                                <div id="gallery_01" class="product-flexslider hidden-buttons product-img-thumb">
                                                    <div class="slider-items slider-width-col4 block-content">
                                                        <?php foreach ($product_img as $img){ ?>
                                                        <div class="more-views-items"> <a href="#" data-image="<?php echo $img['img']; ?>" data-zoom-image="<?php echo $img['img']; ?>"> <img id="product-zoom" src="<?php echo $img['img']; ?>" alt="product-image"> </a></div>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end: more-images -->
                                </div>
                                <div class="product-shop col-lg-8 col-sm-7 col-xs-12">
                                    <div class="product-name">
                                        <h1><?php echo $product['product_name']; ?></h1>
                                    </div>
                                    <div class="ratings">
                                        <div class="rating-box">
                                            <div style="width:<?php echo$average_rating*20;?>%" class="rating"></div>
                                        </div>
                                        <p class="rating-links"> <a href="#"><?php echo $total_rating;?> Review(s)</a> <span class="separator">|</span> <a href="#">Add Your Review</a> </p>
                                    </div>
                                    <div class="price-block">
                                        <div class="price-box">
                                            <p class="special-price"> <span class="price-label">Special Price</span> <span id="product-price-48" class="price"> $<?php echo($product['price'] - ($product['price'] * ($product['discount'] / 100)));?> </span> </p>
                                            <p class="old-price"> <span class="price-label">Regular Price:</span> <span class="price"> $<?php echo $product['price']; ?> </span> </p>
                                            <p class="availability in-stock pull-right"><span>In Stock</span></p>
                                        </div>
                                    </div>
                                    <div class="add-to-box">
                                        <div class="add-to-cart">
                                            <?php if($product['quantity']<=0){ ?>
                                                <button class='button btn-cart' title='het hang' type='button'>Hết Hàng</button>
                                            <?php }else{ ?>
                                            <div class="pull-left">
                                                <div class="custom pull-left">
                                                    <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 0 ) result.value--;return false;" class="reduced items-count" type="button"><i class="fa fa-minus">&nbsp;</i></button>
                                                    <input type="text" class="input-text qty" title="Qty" value="1" maxlength="12" id="qty" name="qty" disable>
                                                    <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items-count" type="button"><i class="fa fa-plus">&nbsp;</i></button>
                                                </div>
                                            </div>
                                            <?php if(isset($_SESSION['username'])){ ?>
                                                <button class='button btn-cart' title='Add to Cart' type='button'>Add to Cart</button>
                                            <?php }else{ ?>
                                                <a href='index.php?page=login'><button class='button btn-cart' title='Add to Cart' type='button'>Add to Cart</button></a>
                                            <?php }}?>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="product-collateral col-lg-12 col-sm-12 col-xs-12">
                    <div class="add_info">
                        <ul id="product-detail-tab" class="nav nav-tabs product-tabs">
                            <li class="active"> <a href="#product_tabs_description" data-toggle="tab"> Product Description </a> </li>
                            <li> <a href="#reviews_tabs" data-toggle="tab">Reviews</a> </li>
                        </ul>
                        <div id="productTabContent" class="tab-content">
                            <div class="tab-pane fade in active" id="product_tabs_description">
                                <div class="std">
                                    <p><?php echo $product['description']; ?></p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="reviews_tabs">
                                <div class="box-collateral box-reviews" id="customer-reviews">
                                    <div class="box-reviews1">
                                        <div class="form-add">
                                            <div>
                                                <?php if(!isset($_SESSION['user_id'])){
                                                    echo "Login to comment <a href='index.php?page=login'>Login</a>";
                                                }else{ ?>
                                                    <form id="review-form" method="post" action="">
                                                    <h3>Write Your Own Review</h3>
                                                    <fieldset>
                                                        <h4>How do you rate this product? <em class="required">*</em></h4>
                                                        <span id="input-message-box"></span>
                                                        <table id="product-review-table" class="data-table">
                                                            <thead>
                                                            <tr class="first last">
                                                                <th><span class="nobr">1 *</span></th>
                                                                <th><span class="nobr">2 *</span></th>
                                                                <th><span class="nobr">3 *</span></th>
                                                                <th><span class="nobr">4 *</span></th>
                                                                <th><span class="nobr">5 *</span></th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <tr class="first odd">
                                                                <td class="value"><input type="radio" class="radio" value="1" id="Price_1" name="ratings"></td>
                                                                <td class="value"><input type="radio" class="radio" value="2" id="Price_2" name="ratings"></td>
                                                                <td class="value"><input type="radio" class="radio" value="3" id="Price_3" name="ratings"></td>
                                                                <td class="value"><input type="radio" class="radio" value="4" id="Price_4" name="ratings"></td>
                                                                <td class="value last"><input type="radio" class="radio" value="5" id="Price_5" name="ratings"></td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                        <input type="hidden" value="" class="validate-rating" name="validate_rating">
                                                        <div class="review2">
                                                            <ul>
                                                                <li>
                                                                    <label class="required " for="review_field">Review<em>*</em></label>
                                                                    <div class="input-box">
                                                                        <textarea rows="3" cols="5" id="review_field" name="comment"></textarea>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                            <div class="buttons-set">
                                                                <button class="button submit" title="Submit Review" type="submit"><span>Submit Review</span></button>
                                                            </div>
                                                        </div>
                                                    </fieldset>
                                                </form>
                                                <?php }?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box-reviews2">
                                        <h3>Customer Reviews</h3>
                                        <div class="box visible">
                                            <ul>

                                    <?php include_once 'server/Rating.php'; ?>
                                    <?php
                                    foreach ($Rating_Comment as $value){
                                        if($value['comment'] != null){
                                    ?>          <li>
                                                    <div class="review">
                                                        <h6 style="display:inline-block"><a href="#"><?php $user = $User_Controller->getUser($value['user_id']); echo $user['user_name'];?></a></h6>
                                                        <table class="ratings-table">
                                                            <tbody>
                                                            <tr>
                                                                <td><div class="rating-box">
                                                                        <div class="rating" style="width:<?php echo $value['rating']*20;?>%;"></div>
                                                                    </div></td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                        <small>Review on <?php echo $value['creat_at']; ?> </small>
                                                        <div class="review-txt"> <?php echo $value['comment']; ?></div>
                                                    </div>
                                                </li>
                                    <?php }}?>
                                            </ul>
                                        </div>
                                        <div class="actions"> <a class="button view-all" id="revies-button" href="#"><span><span>View all</span></span></a> </div>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Main Container End -->

<!-- Related Products Slider -->

<div class="container">

    <!-- Related Slider -->
    <div class="related-pro">
        <div class="slider-items-products">
            <div class="related-block">
                <div id="related-products-slider" class="product-flexslider hidden-buttons">
                    <div class="home-block-inner">
                        <div class="block-title">
                            <h2>Related Products</h2>
                            <div class="hidden-xs hidden-sm">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                        </div>
                    </div>
                    <div class="slider-items slider-width-col4 products-grid block-content">
                        <?php $Related_product = $ProductModel->getNewProduct($ProductCate['id'],6);
                            foreach($Related_product as $Related_Product){
                                $Rating_Comment = $ProductModel->GetRating($Related_Product['id']);
                                $total_rating = 0;
                                foreach($Rating_Comment as $value){
                                    $totalStar = $totalStar + $value['rating'];
                                    $total_rating++;
                                }
                                $average_rating = $ProductModel->CountStar($Related_Product['id']);
                        ?>
                        <!-- Item -->
                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a class="product-image" title="Retis lapen casen" href="?page=product_detail&slug=<?php echo $Related_Product['slug']; ?>">
                                            <img alt="Retis lapen casen" src="<?php echo $Related_Product['img']; ?>">
                                        </a>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"> <a title="Retis lapen casen" href="?page=product_detail&slug=<?php echo $Related_Product['slug']; ?>"> <?php echo $Related_Product['product_name']; ?></a> </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:<?php echo $average_rating*20;?>%" class="rating"></div>
                                                    </div>
                                                    <p class="rating-links"> <a href="#"><?php echo $total_rating; ?> Review(s)</a> <span class="separator">|</span> <a href="#">Add Review</a> </p>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box"> <span class="regular-price"> <span class="price">$<?php echo($Related_Product['price'] *(1 - ($Related_Product['discount'] / 100))); ?></span> </span> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Item -->
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End related products Slider -->

</div>
<!-- Related Products Slider End -->

<!-- Upsell Product Slider -->

<div class="container">
    <!-- upsell Slider -->
    <div class="upsell-pro">
        <div class="slider-items-products">
            <div class="upsell-block">
                <div id="upsell-products-slider" class="product-flexslider hidden-buttons">
                    <div class="home-block-inner">
                        <div class="block-title">
                            <h2>Upsell Product</h2>
                            <div class="hidden-xs hidden-sm">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                        </div>
                    </div>
                    <div class="slider-items slider-width-col4 products-grid block-content">
                        <?php $Upsell = $ProductModel->getProductbyStt(4,0,7);
                        foreach($Upsell as $Upsell_product){
                        $Rating_Comment = $ProductModel->GetRating($Upsell_product['id']);
                        $total_rating = 0;
                        foreach($Rating_Comment as $value_4){
                            $totalStar = $totalStar + $value_4['rating'];
                            $total_rating++;
                        }
                        $average_rating = $ProductModel->CountStar($Upsell_product['id']);
                        ?>
                        <!-- Item -->
                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a class="product-image" title="Retis lapen casen" href="?page=product_detail&slug=<?php echo $Upsell_product['slug']; ?>">
                                            <img alt="Retis lapen casen" src="<?php echo $Upsell_product['img']; ?>">
                                        </a>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"> <a title="Retis lapen casen" href="?page=product_detail&slug=<?php echo $Upsell_product['slug']; ?>"> <?php echo $Upsell_product['product_name']; ?> </a> </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:<?php echo $average_rating*20;?>%" class="rating"></div>
                                                    </div>
                                                    <p class="rating-links"> <a href="#"><?php echo $total_rating; ?> Review(s)</a> <span class="separator">|</span> <a href="#">Add Review</a> </p>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box"> <span class="regular-price"> <span class="price">$<?php echo($Upsell_product['price'] *(1 - ($Upsell_product['discount'] / 100))); ?></span> </span> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Item -->
                        <?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Upsell  Slider -->
</div>
<script>
    $(function(){
        $('#product_addtocart_form').submit(function(e){
            var product_id = $('#Product_id').val();
            var qty = $('#qty').val();

            e.preventDefault();
            $.ajax({
                url : 'server/AddToCart.php',
                type : 'POST',
                dateType : 'html',
                data: { product_id : product_id, qty : qty },

                success : function(data){
                    $(".notice").html(data);
                },

                error : function(){
                    console.log('error');
                },
            });
        });

        $('.btn-cart').click(function(){
            $('#product_addtocart_form').submit()
        })
    });
</script>