<?php
include_once 'controller/Product_Controller.php';
$CateModel = new CateModel(); // gọi Class CateModel bên model/CateModel.php
$CateRoot = $CateModel->CateRoot(); // hàm Cate mẹ

$ProductController = new Product_Controller();
?>
<!-- features box -->
<div class="our-features-box hidden-xs">
    <div class="container">
        <div class="features-block">
            <div class="col-md-3 col-xs-12 col-sm-6">
                <div class="feature-box first"><span class="fa fa-truck">&nbsp;</span>
                    <div class="content">
                        <h3>FREE SHIPPING WORLDWIDE</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 col-sm-6">
                <div class="feature-box"><span class="fa fa-headphones">&nbsp;</span>
                    <div class="content">
                        <h3>24X7 CUSTOMER SUPPORT</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 col-sm-6">
                <div class="feature-box"><span class="fa fa-dollar">&nbsp;</span>
                    <div class="content">
                        <h3>MONEY BACK GUARANTEE</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 col-sm-6">
                <div class="feature-box last"><span class="fa fa-mobile">&nbsp;</span>
                    <div class="content">
                        <h3>Hotline +(888) 123-4567</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Slider -->
<div id="magik-slideshow" class="magik-slideshow">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div id='rev_slider_4_wrapper' class='rev_slider_wrapper fullwidthbanner-container'>
                    <div id='rev_slider_4' class='rev_slider fullwidthabanner'>
                        <ul>
                            <li data-transition='random' data-slotamount='7' data-masterspeed='1000'
                                data-thumb='images/slide-img1.jpg'><img src='images/slide-img1.jpg' alt="slide-img"
                                                                        data-bgposition='left top' data-bgfit='cover'
                                                                        data-bgrepeat='no-repeat'>
                                <div class="info">
                                    <div class='tp-caption ExtraLargeTitle sft  tp-resizeme ' data-endspeed='500'
                                         data-speed='500' data-start='1100' data-easing='Linear.easeNone'
                                         data-splitin='none' data-splitout='none' data-elementdelay='0.1'
                                         data-endelementdelay='0.1'
                                         style='z-index:2;max-width:auto;max-height:auto;white-space:nowrap;'><span>Womens style</span>
                                    </div>
                                    <div class='tp-caption LargeTitle sfl  tp-resizeme ' data-endspeed='500'
                                         data-speed='500' data-start='1300' data-easing='Linear.easeNone'
                                         data-splitin='none' data-splitout='none' data-elementdelay='0.1'
                                         data-endelementdelay='0.1'
                                         style='z-index:3;max-width:auto;max-height:auto;white-space:nowrap;'><span>Collection 2016</span>
                                    </div>
                                    <div class='tp-caption Title sft  tp-resizeme ' data-endspeed='500' data-speed='500'
                                         data-start='1450' data-easing='Power2.easeInOut' data-splitin='none'
                                         data-splitout='none' data-elementdelay='0.1' data-endelementdelay='0.1'
                                         style='z-index:4;max-width:auto;max-height:auto;white-space:nowrap;'>In augue
                                        urna, nunc, tincidunt, augue, augue facilisis facilisis.
                                    </div>
                                    <div class='tp-caption sfb  tp-resizeme ' data-endspeed='500' data-speed='500'
                                         data-start='1500' data-easing='Linear.easeNone' data-splitin='none'
                                         data-splitout='none' data-elementdelay='0.1' data-endelementdelay='0.1'
                                         style='z-index:4;max-width:auto;max-height:auto;white-space:nowrap;'><a
                                                href='#' class="buy-btn">Shop Now</a></div>
                                </div>
                            </li>
                            <li data-transition='random' data-slotamount='7' data-masterspeed='1000'
                                data-thumb='images/slide-img2.jpg'><img src='images/slide-img2.jpg' alt="slide-img"
                                                                        data-bgposition='left top' data-bgfit='cover'
                                                                        data-bgrepeat='no-repeat'>
                                <div class="info">
                                    <div class='tp-caption ExtraLargeTitle sft slide2  tp-resizeme ' data-endspeed='500'
                                         data-speed='500' data-start='1100' data-easing='Linear.easeNone'
                                         data-splitin='none' data-splitout='none' data-elementdelay='0.1'
                                         data-endelementdelay='0.1'
                                         style='z-index:2;max-width:auto;max-height:auto;white-space:nowrap;padding-right:0px'>
                                        <span>Super Sale</span></div>
                                    <div class='tp-caption LargeTitle sfl  tp-resizeme ' data-endspeed='500'
                                         data-speed='500' data-start='1300' data-easing='Linear.easeNone'
                                         data-splitin='none' data-splitout='none' data-elementdelay='0.1'
                                         data-endelementdelay='0.1'
                                         style='z-index:3;max-width:auto;max-height:auto;white-space:nowrap;'>Summer
                                        Season
                                    </div>
                                    <div class='tp-caption Title sft  tp-resizeme ' data-endspeed='500' data-speed='500'
                                         data-start='1500' data-easing='Power2.easeInOut' data-splitin='none'
                                         data-splitout='none' data-elementdelay='0.1' data-endelementdelay='0.1'
                                         style='z-index:4;max-width:auto;max-height:auto;white-space:nowrap;'>Lorem
                                        ipsum dolor sit amet, consectetur adipiscing elit.
                                    </div>
                                    <div class='tp-caption sfb  tp-resizeme ' data-endspeed='500' data-speed='500'
                                         data-start='1500' data-easing='Linear.easeNone' data-splitin='none'
                                         data-splitout='none' data-elementdelay='0.1' data-endelementdelay='0.1'
                                         style='z-index:4;max-width:auto;max-height:auto;white-space:nowrap;'><a
                                                href='#' class="buy-btn">Buy Now</a></div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-3 hot-deal">
                <ul class="products-grid">
                    <?php $HotDeal = $ProductController->getProductbyStt(3,0,1);
                    foreach($HotDeal as $Hot_Deal_product){
                    $Rating_Comment = $ProductController->GetRating($Hot_Deal_product['id']);
                    $total_rating = 0;
                    foreach($Rating_Comment as $value_3){
                        $totalStar = $totalStar + $value_3['rating'];
                        $total_rating++;
                    }
                    $average_rating = $ProductController->CountStar($Hot_Deal_product['id']);
                    ?>
                    <li class="right-space two-height item">
                        <div class="item-inner">
                            <div class="item-img">
                                <div class="item-img-info">
                                    <a href="product-<?php echo $Hot_Deal_product['slug']; ?>" title="Retis lapen casen" class="product-image">
                                        <img src="<?php echo $Hot_Deal_product['img']; ?>" alt="Retis lapen casen"> </a>
                                    <div class="hot-label hot-top-left">Hot Deal</div>
                                    <div class="box-timer">
                                        <div class="countbox_1 timer-grid"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="item-info">
                                <div class="info-inner">
                                    <div class="item-title">
                                        <a href="product-<?php echo $Hot_Deal_product['slug']; ?>" title="Retis lapen casen">
                                            Retis lapen casen </a>
                                    </div>
                                    <div class="item-content">
                                        <div class="rating">
                                            <div class="ratings">
                                                <div class="rating-box">
                                                    <div class="rating" style="width:<?php echo $average_rating*20;?>%"></div>
                                                </div>
                                                <p class="rating-links">
                                                    <a href="#"><?php echo $total_rating; ?> Review(s)</a>
                                                    <span class="separator">|</span>
                                                    <a href="#">Add Review</a></p>
                                            </div>
                                        </div>
                                        <div class="item-price">
                                            <div class="price-box"><span class="regular-price"> <span class="price">$<?php echo($Hot_Deal_product['price'] *(1 - ($Hot_Deal_product['discount'] / 100))); ?></span> </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php }?>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- end Slider -->

<!-- mob features box -->
<div class="our-features-box hidden-lg hidden-sm hidden-md">
    <div class="container">
        <div class="features-block">
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box first"><span class="fa fa-truck"></span>
                    <div class="content">
                        <h3>FREE SHIPPING WORLDWIDE</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box"><span class="fa fa-headphones"></span>
                    <div class="content">
                        <h3>24X7 CUSTOMER SUPPORT</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box"><span class="fa fa-dollar"></span>
                    <div class="content">
                        <h3>MONEY BACK GUARANTEE</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box last"><span class="fa fa-mobile"></span>
                    <div class="content">
                        <h3>Hotline +(888) 123-4567</h3>
                        Lorem ipsum dolor sit amet.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- New Products  + Tab -->
<div class="content-page">
    <div class="container">
        <!-- featured category -->
        <div class="category-product">
            <div class="navbar nav-menu">
                <div class="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <div class="new_title">
                                <h2>New Products</h2>
                            </div>
                        </li>
                        <?php

                        foreach ($CateRoot as $keyCate => $Cate_root) {
                            if ($keyCate == 0) {
                                ?>
                                <li class="active">
                                    <a data-toggle="tab" href="#tab-<?php echo($keyCate + 1); ?>">
                                        <?php echo $Cate_root['cate_name']; ?>
                                    </a>
                                </li>
                            <?php } else { ?>
                                <li>
                                    <a data-toggle="tab" href="#tab-<?php echo($keyCate + 1); ?>">
                                        <?php echo $Cate_root['cate_name'];; ?>
                                    </a>
                                </li>
                            <?php } ?>
                        <?php } ?>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

            </div>
            <div class="product-bestseller">
                <div class="product-bestseller-content">
                    <div class="product-bestseller-list">
                        <div class="tab-container">
                            <!-- tab product -->
                            <?php
                            foreach ($CateRoot as $keyCate => $Cate_root) {
                                    ?>
                                    <div class="tab-panel <?php if($keyCate == 0){echo 'active';}?>" id="tab-<?php echo($keyCate + 1); ?>">
                                        <div class="category-products">
                                            <ul class="products-grid">
                                                <?php $Cate = [$Cate_root['id']]; ?>
                                                <?php foreach ($CateModel->Cate_Child($Cate_root['id']) as $Cate_one) {
                                                    $Cate[] = $Cate_one['id'];
                                                    foreach ($CateModel->Cate_Child($Cate_one['id']) as $Cate_two) {
                                                        $Cate[] = $Cate_two['id']; // lay id cate con?>
                                                    <?php } ?>
                                                <?php }
                                                $string = implode(',', $Cate); // chuyen mang thanh chuoi
                                                ?>
                                                <?php $getProduct = $ProductController->getNewProduct($string,4);
                                                foreach ($getProduct as $product) {
                                                    $Rating_Comment = $ProductController->GetRating($product['id']);
                                                    $total_rating = 0;
                                                    foreach($Rating_Comment as $value){
                                                        $totalStar = $totalStar + $value['rating'];
                                                        $total_rating++;
                                                    }
                                                    $average_rating = $ProductController->CountStar($product['id']);
                                                    ?>
                                                    <li class="item col-lg-3 col-md-3 col-sm-4 col-xs-6">
                                                        <div class="item-inner">
                                                            <div class="item-img">
                                                                <div class="item-img-info">
                                                                    <a class="product-image" title="Retis lapen casen" href="product-<?php echo $product['slug']; ?>">
                                                                        <img alt="Retis lapen casen"
                                                                             src="<?php echo $product['img']; ?>">
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <div class="info-inner">
                                                                    <div class="item-title"><a title="Retis lapen casen"
                                                                                               href="product-<?php echo $product['slug']; ?>"> <?php echo $product['product_name']; ?> </a>
                                                                    </div>
                                                                    <div class="item-content">
                                                                        <div class="rating">
                                                                            <div class="ratings">
                                                                                <div class="rating-box">
                                                                                    <div style="width:<?php echo $average_rating*20;?>%"
                                                                                         class="rating"></div>
                                                                                </div>
                                                                                <p class="rating-links"><a href="#"><?php echo $total_rating; ?>
                                                                                        Review(s)</a> <span
                                                                                            class="separator">|</span>
                                                                                    <a href="#">Add Review</a></p>
                                                                            </div>
                                                                        </div>
                                                                        <div class="item-price">
                                                                            <div class="price-box">
                                                                                <span class="regular-price">
                                                                                    <span class="price">
                                                                                        $<?php echo($product['price'] *(1 - ($product['discount'] / 100))); ?>
                                                                                    </span>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                <?php } ?>
                                            </ul>
                                        </div>
                                    </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- bestsell slider -->
<section class="bestsell-pro">
    <div class="container">
        <div class="slider-items-products">
            <div class="bestsell-block">
                <div id="bestsell-slider" class="product-flexslider hidden-buttons">
                    <div class="home-block-inner"><a href="grid.php"><img src="images/ads-06.jpg" alt="add banner"></a>
                        <div class="banner-content">
                            <div class="banner-text">Women's</div>
                            <div class="banner-text1">20% off</div>
                            <p>on selected products</p>
                            <a href="#" class="view-bnt">Shop now</a></div>
                    </div>
                    <div class="block-title">
                        <h2>Best Sellers</h2>
                        <div class="hidden-xs hidden-sm">Best selling products !!!
                        </div>
                    </div>
                    <div class="slider-items slider-width-col4 products-grid block-content">
                        <?php $Best_Sellers = $ProductController->getProductbyStt(1,0,6);
                        foreach($Best_Sellers as $BestSellers){
                            $Rating_Comment = $ProductController->GetRating($BestSellers['id']);
                            $total_rating = 0;
                            foreach($Rating_Comment as $value_1){
                                $totalStar = $totalStar + $value_1['rating'];
                                $total_rating++;
                            }
                            $average_rating = $ProductController->CountStar($BestSellers['id']);
                            ?>
                        <!-- Item -->
                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a class="product-image" title="Retis lapen casen" href="product-<?php echo $BestSellers['slug']; ?>">
                                            <img alt="Retis lapen casen" src="<?php echo $BestSellers['img']; ?>">
                                        </a>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a title="Retis lapen casen" href="product-<?php echo $BestSellers['slug']; ?>">
                                                <?php echo $BestSellers['product_name'] ?> </a></div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:<?php echo $average_rating*20;?>%" class="rating"></div>
                                                    </div>
                                                    <p class="rating-links"><a href="#"><?php echo $total_rating; ?> Review(s)</a> <span
                                                                class="separator">|</span> <a href="#">Add Review</a>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box"><span class="regular-price"> <span class="price">$<?php echo($BestSellers['price'] *(1 - ($BestSellers['discount'] / 100))); ?></span> </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Item -->
                        <?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Bestsell Slider -->

<!-- Special Product Slider -->
<section class="new-arrivals-pro">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-4 col-xs-12 featured-add-box">
                <div class="featured-add-inner"><a href="#"> <img src="images/ads-07.jpg" alt="f-img"></a>
                    <div class="banner-content">
                        <div class="banner-text">Men's</div>
                        <div class="banner-text1">49% off</div>
                        <p>on selected products</p>
                        <a href="#" class="view-bnt">Shop now</a></div>
                </div>
            </div>
            <div class="col-md-9 col-sm-8 col-xs-12 featured-pro-block">
                <div class="slider-items-products">
                    <div class="new-arrivals-block">
                        <div id="new-arrivals-slider" class="product-flexslider hidden-buttons">
                            <div class="home-block-inner">
                                <div class="block-title">
                                    <h2>Featured Product</h2>
                                </div>
                            </div>
                            <div class="slider-items slider-width-col4 products-grid block-content">
                                <?php $Featured_product = $ProductController->getProductbyStt(2,0,6);
                                foreach($Featured_product as $FeaturedProduct){
                                $Rating_Comment = $ProductController->GetRating($FeaturedProduct['id']);
                                $total_rating = 0;
                                foreach($Rating_Comment as $value_2){
                                    $totalStar = $totalStar + $value_2['rating'];
                                    $total_rating++;
                                }
                                $average_rating = $ProductController->CountStar($FeaturedProduct['id']);
                                ?>
                                <!-- Item -->
                                <div class="item">
                                    <div class="item-inner">
                                        <div class="item-img">
                                            <div class="item-img-info">
                                                <a class="product-image" title="Retis lapen casen" href="product-<?php echo $FeaturedProduct['slug']; ?>">
                                                    <img alt="Retis lapen casen" src="<?php echo $FeaturedProduct['img']; ?>">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="info-inner">
                                                <div class="item-title">
                                                    <a title="Retis lapen casen" href="product-<?php echo $FeaturedProduct['slug']; ?>">
                                                        <?php echo $FeaturedProduct['product_name'] ?>
                                                    </a>
                                                </div>
                                                <div class="item-content">
                                                    <div class="rating">
                                                        <div class="ratings">
                                                            <div class="rating-box">
                                                                <div style="width:<?php echo $average_rating*20;?>%" class="rating"></div>
                                                            </div>
                                                            <p class="rating-links">
                                                                <a href="#"><?php echo $total_rating; ?> Review(s)</a>
                                                                <span class="separator">|</span>
                                                                <a href="#">Add Review</a>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="item-price">
                                                        <div class="price-box">
                                                            <span class="regular-price">
                                                                <span class="price">
                                                                    $<?php echo($FeaturedProduct['price'] *(1 - ($FeaturedProduct['discount'] / 100))); ?>
                                                                </span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Item -->
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Special Product Slider -->

<!-- Testimonials Box Slider -->
<div class="container">
    <div class="row">
        <div class="col-md-6 col-sm-12 testimonials">
            <div class="ts-testimonial-widget">
                <div class="slider-items-products">
                    <div id="testimonials-slider" class="product-flexslider hidden-buttons home-testimonials">
                        <div class="slider-items slider-width-col4 fadeInUp">
                            <div class="holder">
                                <div class="thumb"><img src="images/member1.jpg" alt="testimonials img"></div>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, Lid est laborum dolo rumes
                                    fugats untras. dolore magna aliquam erat volutpat. Aenean est auctorwisiet urna.
                                    Aliquam erat volutpat.</p>
                                <div class="line"></div>
                                <strong class="name">Saraha Smith</strong></div>
                            <div class="holder">
                                <div class="thumb"><img src="images/member2.jpg" alt="testimonials img"></div>
                                <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis
                                    egestas. Nam sapien nunc, convallis in sollicitudin in, ullamcorper ad eulibero.
                                    Etiam cursus eu ipsum egestas.</p>
                                <div class="line"></div>
                                <strong class="name">Mark doe</strong></div>
                            <div class="holder">
                                <div class="thumb"><img src="images/member3.jpg" alt="testimonials img"></div>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh
                                    euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Duis ac turpis.
                                    Donec sit amet eros.</p>
                                <div class="line"></div>
                                <strong class="name">John Doe</strong></div>
                            <div class="holder">
                                <div class="thumb"><img src="images/member4.jpg" alt="testimonials img"></div>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh
                                    euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad
                                    minim veniam, quis nostrud exerci.</p>
                                <div class="line"></div>
                                <strong class="name">Stephen Doe</strong></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Custom Slider -->
        <div class="col-md-6 col-sm-12 custom-slider-wrap">
            <div class="custom-slider-inner">
                <div class="home-custom-slider">
                    <div>
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li class="active" data-target="#carousel-example-generic" data-slide-to="0"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item active"><img src="images/custom-slide2.jpg" alt="slide3">
                                    <div class="carousel-caption">
                                        <h3><a title=" Sample Product" href="#">spring <strong>2016</strong></a></h3>
                                        <span>Men's collection</span> <a class="link" href="#">shop collection</a></div>
                                </div>
                                <div class="item"><img src="images/custom-slide3.jpg" alt="slide2">
                                    <div class="carousel-caption"><span>Huge <strong>sale</strong></span>
                                        <p>save up to <strong>70% OFF</strong> Fahion collection</p>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                                        <a class="link" href="#">Shop Now</a></div>
                                </div>
                                <div class="item"><img src="images/custom-slide1.jpg" alt="slide1">
                                    <div class="carousel-caption"><span>New <strong>Arrivals</strong></span>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy
                                            nibh euismod tincidunt ut laoreet.</p>
                                        <a class="link" href="#">View collection</a></div>
                                </div>
                            </div>
                            <a class="left carousel-control" href="#" data-slide="prev"> <span
                                        class="sr-only">Previous</span> </a> <a class="right carousel-control" href="#"
                                                                                data-slide="next"> <span
                                        class="sr-only">Next</span> </a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>