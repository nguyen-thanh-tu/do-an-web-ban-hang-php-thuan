<?php session_start(); ?>
    <section class="main-container col1-layout">
        <div class="main container">
            <div class="account-login">
                <div class="page-title">
                    <h2>Change password</h2>
                </div>
                <fieldset class="col2-set">
                    <div>
                        <form action="" method="POST" role="form" id="change_pass">
                            <div class="content">
                                <p class="required noti_change_pass">

                                </p>
                                <ul class="form-list">
                                    <?php if($_GET['em']){ ?>
                                        <input type="hidden" title="em" name="em" value="<?php echo $_GET['em']; ?>">
                                    <?php }?>
                                    <?php if ($_SESSION['user_id']) { ?>
                                    <li>
                                        <label for="old_pass">Old Password <span class="required phoneError">*</span></label>
                                        <p class="required noti_old_pass">

                                        </p>
                                        <input type="password" title="old password" class="input-text required-entry" id="old_pass" value="" name="old_pass">
                                    </li>
                                    <?php } ?>
                                    <li>
                                        <label for="new_pass">New Password <span class="required emailError">*</span></label>
                                        <p class="required noti_logup_email">

                                        </p>
                                        <input type="password" title="new password" class="input-text required-entry" id="new_pass" value="" name="new_pass">
                                    </li>
                                    <li>
                                        <label for="Retype">Retype New Password <span class="required">*</span></label>
                                        <p class="required noti_Retype">

                                        </p>
                                        <input type="password" title="Password" id="Retype" class="input-text required-entry validate-password" name="Retype">
                                    </li>
                                </ul>
                                <p class="required">* Required Fields</p>
                                <div class="buttons-set">
                                    <button id="changepass" name="change_pass" type="submit" class="button change_pass"><span>Change password</span></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </fieldset>
            </div>
            <br>
            <br>
            <br>
            <br>
            <br>
        </div>
    </section>
<?php include_once "server/change_pass.php" ?>