﻿<?php
    include_once 'controller/UserController.php';
    $UserController = new UserController();
    $Cart = $UserController->GetToCart();

    $Grand_Total = 0;
?>
<div class="notice">

</div>
<section class="main-container col1-layout">
    <div class="main container">
        <div class="col-main">
            <div class="cart wow bounceInUp animated">
                <div class="page-title">
                    <h2>Shopping Cart</h2>
                </div>
                <div class="table-responsive">
                    <form method="post" action="" id="Update_Cart">
                        <input type="hidden" value="Vwww7itR3zQFe86m" name="form_key">
                        <fieldset>
                            <table class="data-table cart-table" id="shopping-cart-table">
                                <colgroup>
                                    <col width="1">
                                    <col>
                                    <col width="1">
                                    <col width="1">
                                    <col width="1">
                                    <col width="1">
                                    <col width="1">
                                </colgroup>
                                <thead>
                                <tr class="first last">
                                    <th rowspan="1">&nbsp;</th>
                                    <th rowspan="1"><span class="nobr">Product Name</span></th>
                                    <th rowspan="1"></th>
                                    <th colspan="1" class="a-center"><span class="nobr">Unit Price</span></th>
                                    <th class="a-center" rowspan="1">Qty</th>
                                    <th colspan="1" class="a-center">Subtotal</th>
                                    <th class="a-center" rowspan="1">&nbsp;</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($Cart as $CartProduct){ ?>
                                <tr class="first odd">
                                    <td class="image"><a class="product-image" title="Sample Product" href="?page=product_detail&product_id=<?php echo $CartProduct['product_id']; ?>&<?php echo $CartProduct['slug']; ?>"><img width="75" alt="Sample Product" src="<?php echo $CartProduct['img']; ?>"></a></td>
                                    <td><h2 class="product-name"><a href="?page=product_detail&product_id=<?php echo $CartProduct['product_id']; ?>&<?php echo $CartProduct['slug']; ?>"><?php echo $CartProduct['product_name']; ?></a> </h2></td>
                                    <td class="a-center"><a title="Edit item parameters" class="edit-bnt" href="#configure/id/15945/"></a></td>
                                    <td class="a-right"><span class="cart-price"> <span class="price">$<?php echo ($CartProduct['price']*(1-$CartProduct['discount']/100)); ?></span> </span></td>
                                    <td class="a-center movewishlist"><input product_id="<?php echo $CartProduct['product_id']; ?>" maxlength="12" class="input-text qty" title="Qty" size="4" value="<?php echo $CartProduct['qty']; ?>" name="cart[15945][qty]"></td>
                                    <td class="a-right movewishlist"><span class="cart-price"> <span class="price <?php echo $CartProduct['product_id']; ?>">$<?php echo ($CartProduct['price']*(1-$CartProduct['discount']/100))*$CartProduct['qty']; ?></span> </span></td>
                                    <td class="a-center last"><a product_id="<?php echo $CartProduct['product_id']; ?>" class="button remove-item" title="Remove item"><span><span>Remove item</span></span></a ></td>
                                </tr>
                                <?php $Grand_Total = $Grand_Total + ($CartProduct['price']*(1-$CartProduct['discount']/100))*$CartProduct['qty']; } ?>
                                </tbody>
                                <tfoot>
                                <tr class="first last">
                                    <td class="a-right last" colspan="50">
                                        <a href="/">
                                            <button class="button btn-continue" title="Continue Shopping" type="button"><span>Continue Shopping</span></button>
                                        </a>
                                        <button id="empty_cart_button" class="button btn-empty" title="Clear Cart" value="empty_cart" name="update_cart_action" type="submit"><span>Clear Cart</span></button>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>
                        </fieldset>
                    </form>
                </div>
                <!-- BEGIN CART COLLATERALS -->
                <div class="cart-collaterals row">
                    <div class="totals col-sm-12">
                        <h3>Shopping Cart Total</h3>
                        <div class="inner">
                            <table class="table shopping-cart-table-total" id="shopping-cart-totals-table">
                                <colgroup>
                                    <col>
                                    <col width="1">
                                </colgroup>
                                <tbody>
                                <tr>
                                    <td colspan="1" class="a-left" style=""><strong>Grand Total</strong></td>
                                    <td class="a-right" style=""><strong><span class="price Grand_Total">$<?php echo $Grand_Total; ?></span></strong></td>
                                </tr>
                                </tbody>
                            </table>
                            <ul class="checkout">
                                <li>
                                    <?php if($CartProduct['product_id']){ ?><a href="checkout"><button class="button btn-proceed-checkout" title="Proceed to Checkout" type="button"><span>Proceed to Checkout</span></button></a><?php }?>
                                </li>
                            </ul>
                        </div>
                        <!--inner-->

                    </div>
                </div>

                <!--cart-collaterals-->

            </div>
        </div>
    </div>
</section>
<script>
    $(function () {
        $('.qty').change(function(){
            var self = this;
            var product_id = $(this).attr('product_id');
            var product_qty = $(this).val();

            $('#Update_Cart').submit(function(e){
                e.preventDefault();
                $.ajax({
                    url : 'server/UpdateCart.php',
                    type : 'POST',
                    dateType : 'html',
                    data: { product_id : product_id, product_qty : product_qty },

                    success : function(data){
                        $(self).parent().parent().children('.movewishlist').children('.cart-price').children('.price').html(data);
                    },

                    error : function(){
                        console.log('error');
                    },
                });
            });
            $('#Update_Cart').submit();
        });

        $('.remove-item').click(function(){
            var self = this;
            var product_id = $(this).attr('product_id');
            var confirm_del = confirm('Bạn có đồng ý xóa sản phẩm khỏi giỏ hàng không?');
            if(confirm_del){
                $('#Update_Cart').submit(function(e){
                    e.preventDefault();
                    $.ajax({
                        url : 'server/DeleteCart.php',
                        type : 'POST',
                        dateType : 'html',
                        data: { product_id : product_id},

                        success : function(data){
                            $(self).parent().parent().html(data);
                        },

                        error : function(){
                            console.log('error');
                        },
                    });
                });
                $('#Update_Cart').submit();
            }
        });

        $('#empty_cart_button').click(function(){
            var confirm_del = confirm('Bạn có đồng ý xóa giỏ hàng không?');
            if(confirm_del){
                $('#Update_Cart').submit(function(e){
                    var del_cart = 'del_cart';
                    e.preventDefault();
                    $.ajax({
                        url : 'server/DeleteCart.php',
                        type : 'POST',
                        dateType : 'html',
                        data: { del_cart : del_cart},

                        success : function(data){
                            $(".cart").html(data);
                        },

                        error : function(){
                            console.log('error');
                        },
                    });
                });
                $('#Update_Cart').submit();
            }
        })
    })
</script>