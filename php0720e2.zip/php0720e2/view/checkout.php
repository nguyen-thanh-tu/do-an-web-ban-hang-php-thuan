﻿<?php
if ($CartProduct == null){
    header('location: /');
}else{
    include_once 'controller/UserController.php';
    $UserController = new UserController();
    $Cart = $UserController->GetToCart();

    $Grand_Total = 0;
}
?>
<!-- main-container -->
<div class="main-container col2-right-layout">
    <div class="noti"></div>
    <div class="main container">
        <div class="row">
            <form method="post" action="">
            <section class="col-sm-9 wow bounceInUp animated">
                <div class="col-main">
                    <div class="page-title">
                        <h1>Đặt hàng</h1>
                    </div>
                </div>
                <div class="row mb-3">
                        <label for="name" class="col-sm-2 col-form-label">Full name</label>
                        <div class="col-sm-10">
                            <input type="t" class="form-control" id="name" name="name">
                        </div>
                    </div>
                <br>
                <div class="row mb-3">
                        <label for="Phone" class="col-sm-2 col-form-label">Phone</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="Phone" name="phone">
                        </div>
                    </div>
                <br>
                <div class="row mb-3">
                    <label for="Address" class="col-sm-2 col-form-label">Address</label>
                    <div class="col-sm-10" >
                        <input type="text" class="form-control" id="Address" placeholder="Địa chỉ nhận hàng" name="address">
                    </div>
                </div>
                <br>
                <div class="form-floating">
                    <label for="floatingTextarea">Ghi chú</label>
                    <textarea class="form-control" placeholder="Leave a note here" id="floatingTextarea" name="note"></textarea>
                </div>
                <br>
                <div class="col-main">
                    <div class="page-title">
                        <h3>Chi tiết đơn hàng</h3>
                    </div>
                </div>
                <div class="table-responsive">
                <table class="data-table cart-table" id="shopping-cart-table">
                    <colgroup>
                        <col width="1">
                        <col>
                        <col width="1">
                        <col width="1">
                        <col width="1">
                        <col width="1">
                        <col width="1">
                    </colgroup>
                    <thead>
                    <tr class="first last">
                        <th rowspan="1">&nbsp;</th>
                        <th rowspan="1"><span class="nobr">Product Name</span></th>
                        <th rowspan="1"></th>
                        <th colspan="1" class="a-center"><span class="nobr">Unit Price</span></th>
                        <th class="a-center" rowspan="1">Qty</th>
                        <th colspan="1" class="a-center">Subtotal</th>
                        <th class="a-center" rowspan="1">&nbsp;</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($Cart as $CartProduct){?>
                    <tr class="first odd">
                        <td class="image"><a class="product-image" title="Sample Product" href="?page=product_detail&product_id=<?php echo $CartProduct['product_id']; ?>&<?php echo $CartProduct['slug']; ?>"><img width="75" alt="Sample Product" src="<?php echo $CartProduct['img']; ?>"></a></td>
                        <td><h2 class="product-name"><a href="?page=product_detail&product_id=<?php echo $CartProduct['product_id']; ?>&<?php echo $CartProduct['slug']; ?>"><?php echo $CartProduct['product_name']; ?></a> </h2></td>
                        <td class="a-center"><a title="Edit item parameters" class="edit-bnt" href="#configure/id/15945/"></a></td>
                        <td class="a-right"><span class="cart-price"> <span class="price">$<?php echo ($CartProduct['price']*(1-$CartProduct['discount']/100)); ?></span> </span></td>
                        <td class="a-center movewishlist"><?php echo $CartProduct['qty']; ?></td>
                        <td class="a-right movewishlist"><span class="cart-price"> <span class="price">$<?php echo ($CartProduct['price']*(1-$CartProduct['discount']/100))*$CartProduct['qty']; ?></span> </span></td>
                    </tr>
                    <?php $Grand_Total = $Grand_Total + ($CartProduct['price']*(1-$CartProduct['discount']/100))*$CartProduct['qty']; ?>
                    <?php } ?>
                    </tbody>
                </table>
                </div>
                <table class="table shopping-cart-table-total" id="shopping-cart-totals-table">
                    <colgroup>
                        <col>
                        <col width="1">
                    </colgroup>
                    <tfoot>
                    <tr>
                        <td colspan="1" class="a-left" style=""><strong>Grand Total</strong></td>
                        <td class="a-right" style=""><strong><span class="price">$<?php echo $Grand_Total; ?></span></strong></td>
                    </tr>
                    </tfoot>
                    <tbody>
                    <tr>
                        <td colspan="1" class="a-left" style=""> Subtotal </td>
                        <td class="a-right" style=""><span class="price">$<?php echo $Grand_Total; ?></span></td>
                    </tr>
                    </tbody>
                </table>
                <button class="button btn-proceed-checkout" title="Proceed to Checkout" type="submit" name="order"><span>Đặt hàng</span></button>
            </section>
            </form>
        </div>
    </div>
</div>
<!--End main-container -->
<?php
    if(isset($_POST['order'])){
        include_once 'server/Order.php';
    }
?>