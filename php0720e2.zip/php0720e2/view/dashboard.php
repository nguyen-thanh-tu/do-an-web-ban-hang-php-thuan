﻿<?php
if(!isset($_SESSION['user_id'])){
    header('location: /');
}
include_once 'controller/UserController.php';
$UserController = new UserController();

$parent_page = $_GET['start'];
if(!$_GET['start']){
    $parent_page = 1;
}

$limit = 4;
$start = ($parent_page - 1) * $limit;

$ShowOrder = $UserController->ShowOrder($start,$limit);
$total = $UserController->total($UserController->Show_Order());
$total_page = ceil($total/$limit);
?>
<!-- main-container -->
<div class="main-container col2-right-layout">
    <div class="main container">
        <div class="row">
            <section class="col-sm-9 wow bounceInUp animated">
                <div class="col-main">
                    <div class="my-account">
                        <div class="page-title">
                            <h2>My Dashboard</h2>
                        </div>
                        <div class="dashboard">
                            <div class="welcome-msg"> <strong>Hello, <?php echo $_SESSION['username']; ?>!</strong>
                                <p>From your My Account Dashboard you have the ability to view a snapshot of your recent account activity and update your account information. Select a link below to view or edit information.</p>
                                <span>Orders successfully ordered by users are redirected to this page and emailed to notify successful orders to registered emails.</span>
                            </div>
                            <div class="recent-orders">
                                <div class="title-buttons">
                                    <strong>Recent Orders</strong>
                                    <a href="?page=dashboard&start=<?php $pre = $parent_page-1;if($pre<=0){echo $pre=1;}else{echo $pre;};?>"><</a> |
                                    <a href="?page=dashboard&start=<?php $next = $parent_page+1;if($next>=$total_page){echo $next = $total_page;}else{echo $next;}; ?>">></a>
                                </div>
                                <div class="table-responsive">
                                    <table class="data-table" id="my-orders-table">
                                        <col>
                                        <col>
                                        <col>
                                        <col width="1">
                                        <col width="1">
                                        <col width="1">
                                        <thead>
                                        <tr class="first last">
                                            <th>Order #</th>
                                            <th>Date</th>
                                            <th>Ship to</th>
                                            <th><span class="nobr">Order Total</span></th>
                                            <th>Status</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($ShowOrder as $Order){
                                            $prod = $UserController->ProductOrder($Order['id']);
                                            $total = 0;?>
                                            <tr class="last even">
                                                <td><?php echo $Order['id']; ?></td>
                                                <td><?php echo $Order['order_date']; ?></td>
                                                <td><?php echo $Order['address']; ?></td>
                                                <td>
                                                    <span class="price">$
                                                        <?php foreach($prod as $produ){$total = $total+$produ['total'];} echo $total;?>
                                                    </span>
                                                </td>
                                                <td><em><?php switch($Order['order_stt']){
                                                            case 1:
                                                                echo 'Chờ xác nhận';
                                                            break;
                                                            case 2:
                                                                echo 'Đã xác nhận';
                                                                break;
                                                            case 3:
                                                                echo 'Đang giao hàng';
                                                                break;
                                                            case 4:
                                                                echo 'Đã xong';
                                                                break;
                                                            default:
                                                                echo 'Đã hủy đơn';
                                                                break;
                                                        } ?></em></td>
                                                <td class="a-center last"><span class="nobr"> <a href="?page=detail_order&order_id=<?php echo $Order['id']; ?>">View Order</a> <span class="separator"></span></td>
                                            </tr>
                                        <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="box-account">
                                <div class="page-title">
                                    <h2>Account Information</h2>
                                </div>
                                <div class="col2-set">
                                    <div class="col-1">
                                        <h5>Contact Information</h5>
                                        <p>Username: <?php echo $_SESSION['username']; ?><br>
                                           Gmail: <?php echo $_SESSION['email']; ?><br>
                                            <a href="?page=change_pass">Change Password</a> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> </div>
            </section>
        </div>
    </div>
</div>
<!--End main-container -->