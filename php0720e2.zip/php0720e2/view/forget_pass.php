<section class="main-container col1-layout">
    <div class="main container">
        <div class="account-login">
            <div class="page-title">
                <h2>Forget password</h2>
            </div>
            <fieldset class="col2-set">
                <div class="registered-users">
                    <form action="" method="POST" role="form" id="forms_forget_password">
                        <strong>Enter the email that the customer has registered</strong><span class="required Error">*</span>
                        <div class="content">
                            <p class="required noti">

                            </p>
                            <ul class="form-list">
                                <li>
                                    <label for="email">Email Address <span class="required emailError">*</span></label>
                                    <p class="required noti_logup_email">

                                    </p>
                                    <input type="text" title="Email Address" class="input-text required-entry" id="email" value="" name="u_email">
                                </li>
                            </ul>
                            <p class="required">* Required Fields</p>
                            <div class="buttons-set">
                                <button id="forget_password" name="forget_password" type="button" class="button forget_password"><span>Submit</span></button>
                            </div>
                        </div>
                    </form>
                </div>
            </fieldset>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
    </div>
</section>
<script>
    $(function () {
        $('#forget_password').click(function(){
            var email = $('#email').val();
            var forget_password = 'forget_password';
            $('#forms_forget_password').submit(function(e){
                e.preventDefault();
                $.ajax({
                    url : 'server/forget_pass.php',
                    type : 'POST',
                    dateType : 'html',
                    data: { email : email, forget_password : forget_password},

                    success : function(data){
                        $('.noti').html(data);
                    },

                    error : function(){
                        console.log('error');
                    },
                });
            });
            $('#forms_forget_password').submit();
        });
    })
</script>