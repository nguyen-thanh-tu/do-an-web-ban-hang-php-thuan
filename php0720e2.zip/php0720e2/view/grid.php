﻿<?php include_once 'controller/CateController.php';
$CateController = new CateController(); // gọi Class CateModel bên model/CateModel.php
$CateRoot = $CateController->getCate(); // hàm Cate mẹ
?>

<!-- Main Container -->
<section class="main-container col2-left-layout bounceInUp animated">
    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-sm-push-3">
                <div class="category-description std">
                    <div class="slider-items-products">
                        <div id="category-desc-slider" class="product-flexslider hidden-buttons">
                            <div class="slider-items slider-width-col1 owl-carousel owl-theme">

                                <!-- Item -->
                                <div class="item"> <a href="#"><img alt="" src="images/category-img1.jpg"></a>
                                    <div class="cat-img-title cat-bg cat-box">
                                        <div class="small-tag">Fashion 2016</div>
                                        <h2 class="cat-heading">Women Collection</h2>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                                    </div>
                                </div>
                                <!-- End Item -->

                                <!-- Item -->
                                <div class="item"> <a href="#"><img alt="" src="images/category-img2.jpg"></a>
                                    <div class="cat-img-title cat-bg cat-box">
                                        <div class="small-tag">Street Style</div>
                                        <h2 class="cat-heading">New Season</h2>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                                    </div>
                                    <!-- End Item -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                include_once 'controller/Product_Controller.php';

                $getProduct = new Product_Controller();

                $limit = 12; // giới hạn bản ghi
                $current_page = (int)$_GET['page_number']; // trang bat đau

                ////////////////////////
                if(!isset($_GET['page_number'])){
                    $current_page = 1;
                }

                ////////////////////////
                if(isset($_GET['cate'])){

                $cate_id = $_GET['cate'];

                $totalRecord = $getProduct->CountProduct_cate($cate_id);
                }
                if(isset($_REQUEST['search_product'])){
                    $search_product = $_REQUEST['search_product'];

                    $totalRecord = $getProduct->Count_Search_Product($search_product);

                }
                ///////////////////////

                $totalPage = ceil($totalRecord/$limit);

                if($current_page > $totalPage){
                    $current_page = $totalPage;
                }
                if($current_page < 0){
                    $current_page = 1;
                }

                $start =  ($current_page - 1) * $limit;

                ////////////////////////
                if(isset($_GET['cate'])) {
                    $Product = $getProduct->getProduct_cate($cate_id, $start, $limit); // lấy sản phẩm

                    $cate_array = explode(',', $cate_id); // bien chuoi thanh mang

                    $cateName = mysqli_fetch_array(($CateController->CateRootId($cate_array[0])));
                }
                ////////////////////////
                if(isset($_REQUEST['search_product'])){
                    $Product = $getProduct->Search_Product($search_product, $start, $limit); // lấy sản phẩm
                }
                ?>
                <article class="col-main">
                    <h2 class="page-heading"> <span class="page-heading-title"><?php if(isset($cateName)){ echo $cateName['cate_name'];}else if(isset($search_product)){echo $search_product;} ?></span> </h2>
                    <div class="display-product-option">
                        <div class="pager hidden-xs">
                            <div class="pages">
                                <ul class="pagination">
                                    <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo 1;?>">&laquo;</a></li>
                                    <?php
                                    for($Page = 1; $Page <= $totalPage; $Page++){
                                        if($totalPage > 5){
                                        if($current_page == $Page){?>

                                        <?php if($current_page > 2) {?>
                                        <li ><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 2; ?>"><?php echo $current_page - 2; ?></a></li>
                                        <?php }?>
                                        <?php if($current_page > 1) {?>
                                        <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 1; ?>"><?php echo $current_page - 1; ?></a></li>
                                        <?php }?>

                                        <?php if($current_page == $totalPage) {?>
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 2; ?>"><?php echo $current_page - 2; ?></a></li>
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 1; ?>"><?php echo $current_page - 1; ?></a></li>
                                        <?php }else if($current_page == $totalPage - 1){?>
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 1; ?>"><?php echo $current_page - 1; ?></a></li>
                                        <?php  } ?>

                                        <li class="<?php if($current_page == $Page){echo 'active';}?>"><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page; ?>"><?php echo $Page; ?></a></li>

                                        <?php if($current_page < $totalPage) {?>
                                        <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 1; ?>"><?php echo $current_page + 1; ?></a></li>
                                        <?php } ?>
                                        <?php if($current_page < $totalPage - 1) {?>
                                        <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 2; ?>"><?php echo $current_page + 2; ?></a></li>
                                        <?php } ?>

                                        <?php if($current_page == 1) {?>
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 3; ?>"><?php echo $current_page + 3; ?></a></li>
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 4; ?>"><?php echo $current_page + 4; ?></a></li>
                                        <?php }else if($current_page == 2) {?>
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 3; ?>"><?php echo $current_page + 3; ?></a></li>
                                        <?php }?>
                                    <?php }}else{?>
                                        <li class="<?php if($Page == $current_page){echo 'active';}?>"><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $Page; ?>"><?php echo $Page; ?></a></li>
                                    <?php }} ?>
                                    <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $totalPage; ?>">&raquo;</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="category-products">
                        <ul class="products-grid">
<!--                            san pham-->
                            <?php $ProductModel = new ProductModel();
                            if(isset($_GET['cate']) || isset($_REQUEST['search_product'])) {
                            foreach($Product as $key => $Product_Value){
                                $Rating_Comment = $ProductModel->GetRating($Product_Value['id']);
                                $total_rating = 0;
                                foreach($Rating_Comment as $value){
                                    $totalStar = $totalStar + $value['rating'];
                                    $total_rating++;
                                }
                                $average_rating = $ProductModel->CountStar($Product_Value['id']);?>
                            <li class="item col-lg-4 col-md-4 col-sm-4 col-xs-6">
                                <div class="item-inner">
                                    <div class="item-img">
                                        <div class="item-img-info">
                                            <a href="product-<?php echo $Product_Value['slug']; ?>" title="Retis lapen casen" class="product-image">
                                                <img src="<?php echo $Product_Value['img'];?>" alt="Retis lapen casen">
                                            </a>
                                            <?php if($key == 0 || $key == 1 || $key == 2 || $key == 3){
                                                if($current_page == 1){
                                            ?>
                                            <div class="new-label new-top-left">New</div>
                                            <?php }} ?>
                                        </div>
                                    </div>
                                    <div class="item-info">
                                        <div class="info-inner">
                                            <div class="item-title">
                                                <a title="Retis lapen casen" href="product-<?php echo $Product_Value['slug']; ?>">
                                                    <?php echo $Product_Value['product_name']; ?>
                                                </a>
                                            </div>
                                            <div class="item-content">
                                                <div class="rating">
                                                    <div class="ratings">
                                                        <div class="rating-box">
                                                            <div style="width:<?php echo $average_rating*20;?>%" class="rating"></div>
                                                        </div>
                                                        <p class="rating-links"> <a href="#"><?php echo $total_rating; ?> Review(s)</a> <span class="separator">|</span> <a href="#">Add Review</a> </p>
                                                    </div>
                                                </div>
                                                <div class="item-price">
                                                    <div class="price-box">
                                                        <p class="old-price"><span class="price-label">Regular Price:</span>
                                                            <span class="price">$<?php echo $Product_Value['price']; ?> </span>
                                                        </p>
                                                        <p class="special-price"><span class="price-label">Special Price</span>
                                                            <span class="price">$<?php echo($Product_Value['price'] *(1 - ($Product_Value['discount'] / 100))); ?></span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <?php }} ?>
                        </ul>
                    </div>
                    <div class="toolbar">
                        <div class="row">
                            <div class="col-lg-6 col-sm-7 col-md-5">
                                <div class="pager">
                                    <div class="pages">
                                        <label>Page:</label>
                                        <ul class="pagination">
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo 1;?>">&laquo;</a></li>
                                            <?php
                                            for($Page = 1; $Page <= $totalPage; $Page++){
                                                if($totalPage > 5){
                                                    if($current_page == $Page){?>

                                                        <?php if($current_page > 2) {?>
                                                            <li ><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 2; ?>"><?php echo $current_page - 2; ?></a></li>
                                                        <?php }?>
                                                        <?php if($current_page > 1) {?>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 1; ?>"><?php echo $current_page - 1; ?></a></li>
                                                        <?php }?>

                                                        <?php if($current_page == $totalPage) {?>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 2; ?>"><?php echo $current_page - 2; ?></a></li>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 1; ?>"><?php echo $current_page - 1; ?></a></li>
                                                        <?php }else if($current_page == $totalPage - 1){?>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page - 1; ?>"><?php echo $current_page - 1; ?></a></li>
                                                        <?php  } ?>

                                                        <li class="<?php if($current_page == $Page){echo 'active';}?>"><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page; ?>"><?php echo $Page; ?></a></li>

                                                        <?php if($current_page < $totalPage) {?>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 1; ?>"><?php echo $current_page + 1; ?></a></li>
                                                        <?php } ?>
                                                        <?php if($current_page < $totalPage - 1) {?>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 2; ?>"><?php echo $current_page + 2; ?></a></li>
                                                        <?php } ?>

                                                        <?php if($current_page == 1) {?>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 3; ?>"><?php echo $current_page + 3; ?></a></li>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 4; ?>"><?php echo $current_page + 4; ?></a></li>
                                                        <?php }else if($current_page == 2) {?>
                                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $current_page + 3; ?>"><?php echo $current_page + 3; ?></a></li>
                                                        <?php }?>
                                                    <?php }}else{?>
                                                    <li class="<?php if($Page == $current_page){echo 'active';}?>"><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $Page; ?>"><?php echo $Page; ?></a></li>
                                                <?php }} ?>
                                            <li><a href="?page=grid<?php if(isset($_GET['cate'])){ ?>&cate=<?php echo $cate_id; }else if (isset($search_product)){?>&search_product=<?php echo $search_product;} ?>&page_number=<?php echo $totalPage; ?>">&raquo;</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-12 col-md-3">
                                <div id="limiter">
                                    <a class="button-asc left" href="#" title="Set Descending Direction"><span class="top_arrow"></span></a> </div>
                            </div>
                        </div>
                    </div>
                </article>
                <!--	///*///======    End article  ========= //*/// -->
            </div>
            <div class="col-left sidebar col-sm-3 col-xs-12 col-sm-pull-9">
                <aside class="col-left sidebar">
                    <div class="side-nav-categories">
                        <div class="block-title"> Categories </div>
                        <!--block-title-->
                        <!-- BEGIN BOX-CATEGORY -->
                        <div class="box-content box-category">
                            <ul>
                                <?php foreach($CateRoot as $key => $Cate_root){ ?>
                                <li>
<!--                                    lấy chuỗi id cho cate root-->
                                    <?php
                                        $CateRoot = [$Cate_root['id']];
                                        foreach($CateController->Cate_Child($Cate_root['id']) as $Cate_one){
                                            $CateRoot[] = $Cate_one['id'];
                                            foreach ($CateController->Cate_Child($Cate_one['id']) as $Cate_two){
                                                $CateRoot[] = $Cate_two['id'];
                                            }
                                        }
                                        $stringRoot = implode(',', $CateRoot);
                                    ?>
<!--                                 het lấy chuỗi id cho cate root-->
                                    <a class="active" href="?page=grid&cate=<?php echo $stringRoot; ?>">
                                        <?php echo $Cate_root['cate_name'];?>
                                    </a>
                                    <span class="subDropdown minus"></span>
                                    <ul class="level0_415" style="display:block">
                                        <!--level1-->
                                        <?php
                                        foreach($CateController->Cate_Child($Cate_root['id']) as $Cate_one){
//                                            lấy chuỗi id cho Cate cap 1
                                                $CateOne = [$Cate_one['id']];
                                                foreach($CateController->Cate_Child($Cate_one['id']) as $Cate_two){
                                                    $CateOne[] = $Cate_two['id'];
                                                }
                                                $stringOne = implode(',', $CateOne);
//                                                hết lấy chuỗi cho cate cấp 1
                                            ?>
                                        <li>
                                            <a href="?page=grid&cate=<?php echo $stringOne; ?>">
                                                <?php echo $Cate_one['cate_name']; ?>
                                            </a>
                                            <span class="subDropdown plus"></span>
                                            <ul class="level1" style="display:none">
                                                <?php foreach($CateController->Cate_Child($Cate_one['id']) as $Cate_two){
                                                    $CateRoot[] = $Cate_two['id'];
                                                ?>
                                                <li> <a href="?page=grid&cate=<?php echo $Cate_two['id']; ?>"> <?php echo $Cate_two['cate_name']; ?> </a> </li>
                                                <!--end for-each -->
                                                <?php } ?>
                                            </ul>
                                            <!--level1-->
                                        </li>
                                        <?php } ?>
                                    </ul>
                                    <!--level0-->
                                </li>
                                <!--level 0-->
                                <?php } ?>
                            </ul>
                        </div>
                        <!--box-content box-category-->
                    </div>
                    <div class="custom-slider">
                        <div>
                            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li class="active" data-target="#carousel-example-generic" data-slide-to="0"></li>
                                    <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                                    <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="item active"><img src="images/slide3.jpg" alt="slide3">
                                        <div class="carousel-caption">
                                            <h3><a title=" Sample Product" href="#">50% OFF</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                            <a class="link" href="#">Buy Now</a></div>
                                    </div>
                                    <div class="item"><img src="images/slide1.jpg" alt="slide1">
                                        <div class="carousel-caption">
                                            <h3><a title=" Sample Product" href="#">Hot collection</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                    <div class="item"><img src="images/slide2.jpg" alt="slide2">
                                        <div class="carousel-caption">
                                            <h3><a title=" Sample Product" href="#">Summer collection</a></h3>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>
                                <a class="left carousel-control" href="#" data-slide="prev"> <span class="sr-only">Previous</span> </a> <a class="right carousel-control" href="#" data-slide="next"> <span class="sr-only">Next</span> </a></div>
                        </div>
                    </div>
                    <div class="hot-banner"><img alt="banner" src="images/hot-trends-banner.jpg"></div>
                </aside>
            </div>
        </div>
    </div>
</section>
<!-- Main Container End -->