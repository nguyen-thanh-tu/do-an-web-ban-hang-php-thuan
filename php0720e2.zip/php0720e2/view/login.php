﻿<?php session_start(); ?>
<section class="main-container col1-layout">
    <div class="main container">
        <div class="account-login">
            <div class="page-title">
                <h2>Login or Create an Account</h2>
            </div>
            <fieldset class="col2-set">
                <div class="col-1 registered-users">
                    <form action="" method="POST" role="form" id="forms_logup">
                    <strong>Register Customers</strong><span class="required Error">*</span>
                        <div class="content">
                            <p class="required noti_logup">

                            </p>
                            <ul class="form-list">
                                <li>
                                    <label for="username">Username <span class="required usernameError">*</span></label>
                                    <p class="required noti_logup_username">

                                    </p>
                                    <input type="text" title="username" class="input-text required-entry" id="username" value="" name="u_username">
                                </li>
                                <li>
                                    <label for="phone">Phone <span class="required phoneError">*</span></label>
                                    <p class="required noti_logup_phone">

                                    </p>
                                    <input type="number" title="Email Address" class="input-text required-entry" id="phone" value="" name="u_phone">
                                </li>
                                <li>
                                    <label for="email">Email Address <span class="required emailError">*</span></label>
                                    <p class="required noti_logup_email">

                                    </p>
                                    <input type="text" title="Email Address" class="input-text required-entry" id="email" value="" name="u_email">
                                </li>
                                <li>
                                    <label for="password">Password <span class="required">*</span></label>
                                    <p class="required noti_logup_password">

                                    </p>
                                    <input type="password" title="Password" id="password" class="input-text required-entry validate-password" name="u_password">
                                </li>
                            </ul>
                            <p class="required">* Required Fields</p>
                            <div class="buttons-set">
                                <button id="Register" name="Register" type="button" class="button Register"><span>Register</span></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-2 registered-users">
                    <form action="?page=login" method="POST" role="form" id="forms_login">
                    <strong>Login Customers</strong>
                    <div class="content">
                        <p>If you have an account with us, please log in.</p>
                        <div class="error_username">
                            <p class="required noti_login">
                            </p>
                        </div>
                        <ul class="form-list">
                            <li>
                                <label for="username">Username<span class="required">*</span></label>
                                <input type="text" title="username" class="input-text required-entry" id="user_name" value="" name="user_name">
                            </li>
                            <li>
                                <label for="pass">Password <span class="required">*</span></label>
                                <input type="password" title="Password" id="pass" class="input-text required-entry validate-password" value="" name="pass">
                            </li>
                        </ul>
                        <p class="required">* Required Fields</p>
                        <div class="buttons-set">
                            <button id="Login"  name="Login" type="button" class="button Login"><span>Login</span></button>
                            <a class="forgot-word" href="?page=forget_pass">Forgot Your Password?</a> </div>
                    </div>
                    </form>
                </div>
            </fieldset>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
    </div>
</section>
<script>
    $(function () {
        $('#Login').click(function(){
            var username = $('#user_name').val();
            var password = $('#pass').val();
            var Login = 'Login';
            $('#forms_login').submit(function(e){
                e.preventDefault();
                $.ajax({
                    url : 'server/UserLogin.php',
                    type : 'POST',
                    dateType : 'html',
                    data: { username : username, password : password, Login : Login},

                    success : function(data){
                        $(".noti_login").html(data);
                    },
                    error : function(){
                        console.log('error');
                    },
                });
            });
            $('#forms_login').submit();
        });
        $('#Register').click(function(){
            var username = $('#username').val();
            var phone = $('#phone').val();
            var email = $('#email').val();
            var password = $('#password').val();
            var Register = 'Register';
            $('#forms_logup').submit(function(e){
                e.preventDefault();
                $.ajax({
                    url : 'server/UserLogup.php',
                    type : 'POST',
                    dateType : 'html',
                    data: { username : username, password : password, phone : phone, email : email, Register : Register},

                    success : function(data){
                        $('.noti_logup').html(data);
                    },

                    error : function(){
                        console.log('error');
                    },
                });
            });
            $('#forms_logup').submit();
        });
    })
</script>
<?php if(isset($_SESSION['user_id'])){
    header('location: /');
}?>