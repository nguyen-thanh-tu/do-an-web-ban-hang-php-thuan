<?php
error_reporting(0);
    include_once ('../controller/UserController.php');
    $UserController = new UserController();
    global $conn;
    if (isset($_POST['Register'])){
        $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $password = hash('sha256', $_POST['password']);
        // Kiểm tra form trống
        if (!$username || !$password || !$email || !$password)
        {
            echo "Vui lòng nhập đầy đủ thông tin.";
            exit;
        }

        //Kiểm tra tên đăng nhập
        if ($UserController->check_username($username) > 0){
            echo "Username này đã có người dùng.";
            exit;
        }
//
        // Kiểm tra email
        $regexEmail =  "/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix";
        if(!preg_match ($regexEmail, $email)){
            echo "Tên email này không hợp lệ.";
            exit;
        }else if($UserController->check_email($email) > 0){
            echo "Tên email này đã có người dùng.";
            exit;
        }

//      Kiem tra dien thoai
        $regexPhone = "/(03|05|07|08|09|01[2|6|8|9])+([0-9]{8})\b/";
        if(!preg_match($regexPhone, $phone)){
            echo "Số điện thoại không này hợp lệ.";
            exit;
        }else if($UserController->check_phone($phone) > 0){
            echo "Tên Số điện thoại này đã có người dùng.";
            exit;
        }
        $register = $UserController->register($username,$phone,$email,$password);
        if($register){
            echo "Đăng ký thành công.";
            exit;
        }else{
            echo "Đăng ký thất bại.";
            exit;
        }
    }else{
        header('location: /');
    }
    ?>