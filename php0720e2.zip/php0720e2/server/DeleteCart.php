<?php
error_reporting(0);
    session_start();
    include_once ('../controller/UserController.php');
    $UserController = new UserController();

    $user_id = (int)$_SESSION['user_id'];
    if(isset($_POST['product_id'])){

        $product_id = (int)$_POST['product_id'];

        if($product_id == 0 || $product_id == null){
            echo"<div class='notice'><div class='alert alert-success'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <div class='Notice'><strong>Notice:</strong> Xoa That Bai</div>
                    </div></div>";
        }else{
            $SuccesstoCart = $UserController->DeleteCart($user_id,$product_id);

            if(!$SuccesstoCart){
                echo"<div class='notice'><div class='alert alert-success'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <div class='Notice'><strong>Notice:</strong> Xoa That bai</div>
                    </div></div>";
            }else{
                $Cart = $UserController->GetToCart();
                foreach($Cart as $CartProduct){ $Grand_Total = $Grand_Total + ($CartProduct['price']*(1-$CartProduct['discount']/100))*$CartProduct['qty']; }
                echo "<script>$('.Grand_Total').html('";?><?php echo$Grand_Total;?><?php echo"')</script>";
            }
        }
    }else if(isset($_POST['del_cart']) || $_POST['del_cart'] === 'del_cart'){
        $SuccesstoCart = $UserController->DelCartAll($user_id);
    }
?>