<?php
error_reporting(0);
session_start();
include_once "PHPMailer-5.2-stable/class.phpmailer.php";
include_once "PHPMailer-5.2-stable/class.smtp.php";

$email = $_SESSION['email'];

$mail = new PHPMailer();
$mail->IsSMTP(); // set mailer to use SMTP
$mail->Host = "smtp.gmail.com"; // specify main and backup server
$mail->Port = 465; // set the port to use
$mail->SMTPAuth = true; // turn on SMTP authentication
$mail->SMTPSecure = 'ssl';
$mail->Username = "ntu109785@gmail.com"; // your SMTP username or your gmail username
$mail->Password = "kh0ngbiet"; // your SMTP password or your gmail password
$from = "ntu109785@gmail.com"; // Reply to this email
$to = $email; // Recipients email ID
$name="http://php0720e2-3.itpsoft.com.vn/"; // Recipient's name
$mail->From = $from;
$mail->FromName = "http://php0720e2-3.itpsoft.com.vn/"; // Name to indicate where the email came from when the recepient received
$mail->AddAddress($to,$name);
$mail->AddReplyTo($from,"http://php0720e2-3.itpsoft.com.vn/");
$mail->WordWrap = 50; // set word wrap
$mail->IsHTML(true); // send as HTML
$mail->Subject = "Gui mail script from http://php0720e2-3.itpsoft.com.vn/";
if($ok == true){ // ordered
        $mail->Body = "<b>You have successfully ordered. Order number is # ".$value['id']."</b>"; //HTML Body
    $mail->AltBody = "You have successfully ordered. Order number is #".$value['id']; //Text Body

    $mail->Send();
}
?>