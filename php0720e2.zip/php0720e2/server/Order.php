<?php
error_reporting(0);
    session_start();

    $user_id = (int)$_SESSION['user_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $note = $_POST['note'];


    if(!$name || !$phone || !$address){
?>
        <script>
            $(function () {
                $('.noti').html('<div class=\'alert alert-danger\'>\n' +
                    '                <button type=\'button\' class=\'close\' data-dismiss=\'alert\' aria-hidden=\'true\'>&times;</button>\n' +
                    '                <div class=\'Notice\' style="text-align:center;"><strong>Notice:</strong> Không được để trống</div>\n' +
                    '                </div>');
            })
        </script>
<?php
    }else{
        $regexPhone = "/(03|05|07|08|09|01[2|6|8|9])+([0-9]{8})\b/";
        if(!preg_match($regexPhone, $phone)){
?>
        <script>
            $(function () {
                $('.noti').html('<div class=\'alert alert-danger\'>\n' +
                    '                <button type=\'button\' class=\'close\' data-dismiss=\'alert\' aria-hidden=\'true\'>&times;</button>\n' +
                    '                <div class=\'Notice\' style="text-align:center;"><strong>Notice:</strong> Số điện thoại không hợp lệ</div>\n' +
                    '                </div>');
            })
        </script>
<?php
        }else{
            $ok = $UserController->AddtoOrder($user_id,$name,$phone,$address,$note);
            if($ok == true){
                $SuccesstoCart = $UserController->DelCartAll($user_id);
                $order = $UserController->ShowOrder(0,1);
                foreach ($order as $value){}
                include_once "PHPmailer.php";
                header('location: ?page=dashboard');
            }else{
?>
        <script>
            $(function () {
                $('.noti').html('<div class=\'alert alert-danger\'>\n' +
                    '                <button type=\'button\' class=\'close\' data-dismiss=\'alert\' aria-hidden=\'true\'>&times;</button>\n' +
                    '                <div class=\'Notice\' style="text-align:center;"><strong>Notice:</strong> Đặt hàng thất bại </div>\n' +
                    '                </div>');
            })
        </script>
<?php
            }
        }
    }
?>