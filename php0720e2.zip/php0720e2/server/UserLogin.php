<?php
error_reporting(0);
session_start();
include_once ('../controller/UserController.php');
$UserController = new UserController();
global $conn;
if(isset($_POST['Login'])){
    $username = $_POST['username'];
    $password = hash('sha256', $_POST['password']);

    if (mysqli_num_rows($UserController->getUser($username)) > 0){
        $CheckPass = mysqli_fetch_array($UserController->getUser($username));
        if ($password == $CheckPass['password']){
            $_SESSION['user_id'] = $CheckPass['id'];
            $_SESSION['username'] = $username;
            $_SESSION['user_phone'] = $CheckPass['user_phone'];
            $_SESSION['email'] = $CheckPass['email'];
        if(isset($_SESSION['user_id'])){
            ?>
            <script>window.location.href = "/";</script>
            <?php
        }
        }else{
            echo "Sai tên đăng nhập hoặc mật khẩu";
        }
    }else{
        echo "Sai tên đăng nhập hoặc mật khẩu";
    }
}else{
    header('location: /');
}
?>