<?php
header('location: /');
?>