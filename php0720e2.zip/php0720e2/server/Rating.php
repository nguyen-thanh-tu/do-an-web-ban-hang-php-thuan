<?php
error_reporting(0);
    $user_id = $_SESSION['user_id'];
    if($_POST['ratings']){
        $rating = (int)$_POST['ratings'];
        $comment =  $_POST['comment'];
        $check = $ProductModel->TotalRatingProd($product_id,$user_id);
        if($check == 0){
            $add_comment = $ProductModel->AddRating($product_id,$user_id,$rating,$comment);
        }else{
            $edit_comment = $ProductModel->EditRating($product_id,$user_id,$rating,$comment);
        }
        ?>
        <script>
            $('.notice').html("<div class='alert alert-success'>\n" +
                "                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>\n" +
                "                <div class='Notice'><strong>Notice:</strong>Đánh giá thành công</div>\n" +
                "                </div>");
        </script>
        <?php
    }
?>