<?php
error_reporting(0);
    session_start();
    include_once ('../controller/UserController.php');
    $UserController = new UserController();
    if(isset($_POST['product_id']) && isset($_POST['qty']) ){

        $user_id = (int)$_SESSION['user_id'];
        $product_id = (int)$_POST['product_id'];
        $qty = (int)$_POST['qty'];

        $Inventory = $UserController->Inventory($product_id); // số lượng hàng tồn kho
        if($qty <= ceil($Inventory/10)){
            $SuccesstoCart = $UserController->CheckToCart($user_id,$product_id,$qty);

            if($SuccesstoCart){
                echo"<div class='alert alert-success'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <div class='Notice'><strong>Notice:</strong> Add to cart success <a href='shopping-cart'>Xem giỏ hàng</a></div>
                </div>";
            }else{
                echo"<div class='alert alert-success'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <div class='Notice'><strong>Notice:</strong> Add to cart fail</div>
                </div>";
            }
        }else{
            echo"<div class='alert alert-success'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <div class='Notice'><strong>Notice:</strong> Add to cart fail</div>
                </div>";
        }
    }
?>
