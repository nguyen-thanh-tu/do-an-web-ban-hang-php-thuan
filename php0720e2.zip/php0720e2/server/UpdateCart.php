<?php
error_reporting(0);
    session_start();
    include_once ('../controller/UserController.php');
    $UserController = new UserController();

//    include_once ('../controller/Page_Controller.php');
//    $Page_Controller = new Page_Controller();
    if(isset($_POST['product_id']) && isset($_POST['product_qty'])){
        $user_id = (int)$_SESSION['user_id'];
        $product_id = (int)$_POST['product_id'];
        $product_qty = (int)$_POST['product_qty'];

        $Inventory = $UserController->Inventory($product_id); // số lượng hàng tồn kho

        if($product_id <= 0 || $product_qty <= 0 || $product_id == null || $product_qty == null){
            echo"Nhập số hợp lệ";
        }else{
            if($product_qty <= ceil($Inventory/10)){
                $update_cart = $UserController->UpdateCart($user_id,$product_id,$product_qty);
                if(!$update_cart){
                    echo"Câp nhat that bai";
                }else{
                    $product = $UserController->getProduct($product_id);
                    echo '$'.($product['price'] * (1 - $product['discount'] / 100))*$product_qty;

                    $Cart = $UserController->GetToCart();
                    foreach($Cart as $CartProduct){ $Grand_Total = $Grand_Total + ($CartProduct['price']*(1-$CartProduct['discount']/100))*$CartProduct['qty']; }
                    echo "<script>$('.Grand_Total').html('";?><?php echo$Grand_Total;?><?php echo"')</script>";
                }
            }else{
                echo"Nhập số <= ".ceil($Inventory/10);
            }
        }
    }
?>