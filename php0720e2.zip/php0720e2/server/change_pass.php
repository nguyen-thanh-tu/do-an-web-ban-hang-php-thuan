<?php
error_reporting(0);
    $User_Controller = new User_Controller();
    if(isset($_POST['change_pass'])){
        $getUser = $User_Controller->getUser($_SESSION['user_id']);
        $old_pass = hash('sha256', $_POST['old_pass']);
        $new_pass = hash('sha256', $_POST['new_pass']);
        $Retype = hash('sha256', $_POST['Retype']);
        if(isset($_POST['em'])){
            if(empty($_POST['new_pass']) || empty($_POST['Retype'])){
                ?>
                <script>
                    $('.noti_change_pass').html("Must not be left blank\n");
                </script>
                <?php
            }else{
                if($new_pass == $Retype){
                    $getAcc = $User_Controller->getAcc();
                    foreach($getAcc as $acc){
                        if($_POST['em'] == hash('sha256', $acc['email'])){
                            $change_pass = $User_Controller->Change_pass_email($acc['email'],$new_pass);
                            if($change_pass){
                                ?>
                                <script>
                                    $('.noti_change_pass').html("Success !!\n").css('color','green');
                                </script>
                                <?php
                            }else{
                                ?>
                                <script>
                                    $('.noti_change_pass').html("Fail !!\n");
                                </script>
                                <?php
                            }
                        }
                    }
                }else{
                    ?>
                    <script>
                        $('.noti_change_pass').html("Fail !!!\n");
                    </script>
                    <?php
                }
            }
        }else if(empty($_POST['old_pass']) || empty($_POST['new_pass']) || empty($_POST['Retype'])){
            ?>
            <script>
                $('.noti_change_pass').html("Must not be left blank\n");
            </script>
            <?php
        }else{
            if(($old_pass == $getUser['password']) && ($new_pass == $Retype)){
                $change_pass = $User_Controller->Change_pass($_SESSION['user_id'],$new_pass);
                if($change_pass){
                    ?>
                    <script>
                        $('.noti_change_pass').html("Success !!\n").css('color','green');
                    </script>
                    <?php
                }else{
                    ?>
                    <script>
                        $('.noti_change_pass').html("Fail !!\n");
                    </script>
                    <?php
                }
            }else{
                if($new_pass != $Retype){
                    ?>
                    <script>
                        $('.noti_Retype').html("Re-enter is not the same as new password\n");
                    </script>
                    <?php
                }
                if($old_pass != $getUser['password']){
                    ?>
                    <script>
                        $('.noti_old_pass').html("Old password is incorrect\n");
                    </script>
                    <?php
                }
            }
        }
    }
?>